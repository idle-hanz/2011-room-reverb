# Chapter 11 — Variants and a reverb designer

> **Status: STUB, expanded 2026-10-05 — PLANNED (ideas only; no design document, no code).**

**Chapter purpose.** Idle sees the engine as a source for other products, and the app as a *designer*: once a room sounds right, it exports something another product can use. This page lists the ideas as Idle stated them (parent conversation, 5 Oct 2026) so they are kept with the book. None has a source file or a decision yet.

**Sources:** Idle's brainstorm (5 Oct 2026, relayed in the book brief); Chapter 10 for the shared-room plug-in. No research files exist for these items.

## The ideas (all ASSUMED / unscheduled)

- **Reverb designer / code export.** Tune a room, then export code, IR packs or presets for a fixed product. What "code" means (C core plus a frozen parameter set? IRs?) is not decided.
- **Source files for variants.** The documented engine (this book) as the starting point for spin-offs.
- **3-D delay.** Echoes that ping-pong around the room in three dimensions, reusing the image geometry.
- **A nice room with cut-down controls.** A few knobs over a fixed, well-tuned room.
- **Game / film binaural walkthrough.** A listener moving through a virtual environment, rendered binaurally (the binaural mic path exists today, Chapter 7; movement through a scene does not).

## The ideas as pictures (PLANNED, plain English)

*How each idea might feel to a user. No designs or algorithms exist; these are Idle's ideas restated.*

- **The designer.** You use the full program as a workbench: shape the room, choose walls and panels, place mics, listen. When it sounds right you press "export", and out comes something a simpler product can load: a fixed preset, a set of echo fingerprints, or code with the settings baked in. The workbench stays complicated so the product can be simple.
- **The "nice room" plug-in.** One carefully tuned room and three or four knobs (perhaps size, distance, decay, tone). Under the hood it is the same engine with almost everything fixed by the designer.
- **3-D delay.** Instead of echoes bouncing between two speakers, the repeats travel around a virtual room in three dimensions, coming back from the walls and ceiling with the right timing and colour for each surface, and through the right mic pattern or binaural ears.
- **A walk-through for games and film.** A listener (the camera or the player) moves through a virtual building. Each room has its own surfaces; the echoes and tail change smoothly as you walk from a tiled corridor into a carpeted office, rendered binaurally for headphones. The binaural mic exists today (Chapter 7); moving through a scene, several connected rooms, and smooth changes are all unbuilt.
- **Source files for variants.** Because this book documents the engine, a developer (or Ben) could start a new product from the engine and the book rather than from scratch.

## What would have to be true first

The C migration (J2) for a portable core, a stable parameter set after SL7b, and this book's Surfaces and auto-treat chapters complete enough that someone else can rebuild the behaviour (ASSUMED).

## Open / not yet built

All of it. No item is in T1→SL7b.
