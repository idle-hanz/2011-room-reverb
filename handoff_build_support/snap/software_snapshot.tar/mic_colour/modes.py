"""Colour modes. One enum. No Structure-pole mode."""

from __future__ import annotations

MEASURED_SHELF = "MEASURED_SHELF"
BYPASS = "BYPASS"
ASSUMED_TOYS = "ASSUMED_TOYS"

_MODES = (MEASURED_SHELF, BYPASS, ASSUMED_TOYS)

_ALIASES = {
    "MEASURED": MEASURED_SHELF,
    "MEASURED_SHELF": MEASURED_SHELF,
    "BYPASS": BYPASS,
    "ASSUMED_TOYS": ASSUMED_TOYS,
    "ASSUMED": ASSUMED_TOYS,
    "TOYS": ASSUMED_TOYS,
    "LEGACY": ASSUMED_TOYS,
}


def parse_colour_mode(value) -> str:
    """Missing or unknown → MEASURED_SHELF. There is no Structure-pole mode."""
    if value is None:
        return MEASURED_SHELF
    key = str(value).strip().upper().replace("-", "_").replace(" ", "_")
    if not key:
        return MEASURED_SHELF
    return _ALIASES.get(key, MEASURED_SHELF)


def early_toys_for(mode: str) -> bool:
    return parse_colour_mode(mode) == ASSUMED_TOYS


def shelf_in_scalars_for(mode: str) -> bool:
    """L8: only ASSUMED_TOYS keeps the −6 dB level shelf in the inject scalars."""
    return parse_colour_mode(mode) == ASSUMED_TOYS


def fitter_on_for(mode: str) -> bool:
    return parse_colour_mode(mode) == MEASURED_SHELF
