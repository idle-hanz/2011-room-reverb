/* live_stereo — the Play block, one function.
 *
 * 32 lines stay 32 lines. The room loop is the worklet loop: diffuser
 * output y, then × g through the unscaled Hadamard, back into the allpass.
 * With Dffs, that feedback is the previous sample. Loop gain is the value sent in.
 * The 80 ms measured mic FIR is applied on the way out and is not written
 * back into the delay. Direct is filtered, then × 0.55. Early left and
 * right join the FDN line's filter. Centre early stays uncoloured. Two
 * tanks are added before that colour. Speakers get left and right.
 *
 * Each line stores FDN A, early A, FDN B, and early B together at one time
 * index. The ring is the 1000 ms cap plus a few samples for the fractional
 * read. Direct stays its own ring: its time is not the line time.
 *
 * Page build: zig cc -target wasm32-freestanding -O3 -msimd128 -nostdlib
 *   -ffreestanding -Wl,--no-entry -Wl,--export-memory -Wl,--export=live_stereo
 *   -Wl,--max-memory=1073741824
 *   -o software/static/wasm/live_stereo.wasm software/engine/live_stereo.c
 * Export every live_* the worklet calls, not only live_stereo.
 *
 * Room blob (float, magic 1), in order:
 *   g, fdn_wet, direct_wet, early_wet, dry_gain, makeup, gain_a, gain_b,
 *   two, colour_on, mono, direct_index, max_delay_ms, snap, ignored_sr,
 *   mic g,pan,phase × L C R,
 *   peaking on,b0,b1,b2,a1,a2 × 3,
 *   per bus L C R:
 *     32 delay_ms, 32 inject, 32 dffs, 32 air_g, air_lp,
 *     32 × (shelf on,b0,b1,b2,a1,a2), dir_ms, dir_gain,
 *     the same block again for source B.
 * Route (int), in order: fdn[3][32], early L/R [2][32], early B L/R [2][32],
 * direct[3], direct B[3]. -1 is a wire. < -1 is silent.
 */

#if defined(_MSC_VER)
#define LS_API __declspec(dllexport)
#define LS_ALIGN16 __declspec(align(16))
#else
#define LS_API __attribute__((visibility("default")))
#define LS_ALIGN16 __attribute__((aligned(16)))
#endif
#if defined(__wasm__)
#define LS_EXPORT(name) __attribute__((export_name(name))) LS_API
#else
#define LS_EXPORT(name) LS_API
#endif

typedef struct LiveStereo LiveStereo;

enum {
    N = 32,
    PART = 128,
    FFTN = 256,
    MAX_PART = 64,
    MAX_IRS = 64,
    MAX_FILT = 112,
    /* 1000 ms is the delay cap. These extra samples cover the fractional read. */
    RING_GUARD = 8,
    CAP_MAX = 192000,
    LANES = 4,
    LANE_FDN = 0,
    LANE_EARLY = 1,
    LANE_FDNB = 2,
    LANE_EARLYB = 3,
    MAX_BLOB = 8192,
    MAX_IR_FLOATS = MAX_IRS * 8192,
    MAX_AUDIO = 2048,
    ROUTE_LEN = 3 * 32 + 2 * 32 + 2 * 32 + 3 + 3,
    BUS_L = 0,
    BUS_C = 1,
    BUS_R = 2
};

static const double DIRECT_FOLD = 0.55;
static const double SMOOTH = 0.0025;

typedef struct Line {
    double delay, delayT, delayB, delayBT;
    double dffs, dffsB, inj, injB;
    double airG, airGb, airLp;
    double airZ, airZe, airZb, airZf;
    int shelfOn, shelfOnB;
    double sb0, sb1, sb2, sa1, sa2;
    double sb0b, sb1b, sb2b, sa1b, sa2b;
    double sz1, sz2, sz1e, sz2e, sz1b, sz2b, sz1f, sz2f;
    double pz1, pz2, pz1b, pz2b;
    int w;
} Line;

typedef struct Bus {
    Line line[N];
    double dirD, dirDT, dirDB, dirDBT;
    double dirGain, dirGainB;
    int dirW, dirWB;
    int anyDffs, anyDffsB;
    double fb[N], fbB[N];
} Bus;

typedef struct Filt {
    int used;
    int bus;
    int kind;
    int ir;
    int npart;
    int pos;
    int cold;
    int seen;
    float prev[PART];
} Filt;

struct LiveStereo {
    int magic;
    int ready;
    int sr;
    int cap;
    int maxDelay;
    int two;
    int colour_on;
    int mono;
    int n_irs;
    int direct_index;
    double g, fdn_wet, direct_wet, early_wet, dry_gain, makeup, gain_a, gain_b;
    double micG[3], micPan[3], micPh[3];
    int peakOn[3];
    double pb0[3], pb1[3], pb2[3], pa1[3], pa2[3];
    Bus bus[3];
    int fdnIdx[3][N];
    int earlyIdx[2][N];
    int earlyBIdx[2][N];
    int directIdx[3];
    int directBIdx[3];
    int irLen[MAX_IRS];
    int irNpart[MAX_IRS];
    Filt filt[MAX_FILT];
    float *dir[3];
    float *dirB[3];
    /* cap * LANES floats: FDN A, early A, FDN B, early B at each time index. */
    float *ring[3][N];
    float *slab;
    int slabN;
    float *specRe;
    float *specIm;
    float *fdlRe;
    float *fdlIm;
    float *blob;
    float *irScratch;
    int *lenScratch;
    int *routeScratch;
    float *inL;
    float *inR;
    float *outL;
    float *outR;
    double yBlk[3][N][PART];
    double eaBlk[3][N][PART];
    double ebBlk[3][N][PART];
    double daBlk[3][PART];
    double dbBlk[3][PART];
    double esBlk[3][PART];
    double dryBlk[PART];
    double reads[N];
    double delayed[N];
    double xinArr[N];
    double yA[N];
    double yB[N];
    float pendL[PART];
    float pendR[PART];
    int pendN;
    float qL[PART];
    float qR[PART];
    int qN, qAt;
    float firIn[MAX_FILT][PART];
};

static LS_ALIGN16 float g_wre[FFTN];
static LS_ALIGN16 float g_wim[FFTN];
static int g_wready = 0;
static LS_ALIGN16 float g_re[FFTN];
static LS_ALIGN16 float g_im[FFTN];
static LS_ALIGN16 float g_accR[FFTN];
static LS_ALIGN16 float g_accI[FFTN];

static void ls_zero(void *dst, int n) {
    unsigned char *d = (unsigned char *)dst;
    unsigned long long *w;
    int i, n8;
    if (!dst || n <= 0) return;
    w = (unsigned long long *)dst;
    n8 = n >> 3;
    for (i = 0; i < n8; i++) w[i] = 0;
    for (i = n8 << 3; i < n; i++) d[i] = 0;
}

static int ptr_aligned4(const void *p) {
    union { const void *p; unsigned char b[sizeof(void *)]; } x;
    x.p = p;
    return (x.b[0] & 3) == 0;
}

static void ls_copy(void *dst, const void *src, int n) {
    unsigned char *d = (unsigned char *)dst;
    const unsigned char *s = (const unsigned char *)src;
    int i = 0;
    if (n >= 4 && ptr_aligned4(d) && ptr_aligned4(s)) {
        float *df = (float *)dst;
        const float *sf = (const float *)src;
        int n4 = n >> 2;
        for (; i < n4; i++) df[i] = sf[i];
        i = n4 << 2;
    }
    for (; i < n; i++) d[i] = s[i];
}

#if defined(__wasm__)
void *memcpy(void *dst, const void *src, unsigned long n) {
    ls_copy(dst, src, (int)n);
    return dst;
}
void *memset(void *dst, int c, unsigned long n) {
    unsigned char *d = (unsigned char *)dst;
    unsigned long i;
    for (i = 0; i < n; i++) d[i] = (unsigned char)c;
    return dst;
}
#endif

static int cap_for(int sr) {
    int c;
    if (sr < 8000) sr = 48000;
    c = sr + RING_GUARD;
    if (c < 256 + RING_GUARD) c = 256 + RING_GUARD;
    if (c > CAP_MAX) c = CAP_MAX;
    return c;
}

static int align_up(int n) {
    return (n + 31) & ~31;
}

static int layout_bytes(int sr) {
    int cap = cap_for(sr);
    int used = align_up((int)sizeof(LiveStereo));
    int slab = 3 * (2 + N * 4) * cap;
    int spec = MAX_IRS * MAX_PART * FFTN;
    int fdl = MAX_FILT * MAX_PART * FFTN;
    used = align_up(used + slab * (int)sizeof(float));
    used = align_up(used + spec * (int)sizeof(float));
    used = align_up(used + spec * (int)sizeof(float));
    used = align_up(used + fdl * (int)sizeof(float));
    used = align_up(used + fdl * (int)sizeof(float));
    used = align_up(used + MAX_BLOB * (int)sizeof(float));
    used = align_up(used + MAX_IR_FLOATS * (int)sizeof(float));
    used = align_up(used + MAX_IRS * (int)sizeof(int));
    used = align_up(used + ROUTE_LEN * (int)sizeof(int));
    used = align_up(used + MAX_AUDIO * (int)sizeof(float));
    used = align_up(used + MAX_AUDIO * (int)sizeof(float));
    used = align_up(used + MAX_AUDIO * (int)sizeof(float));
    used = align_up(used + MAX_AUDIO * (int)sizeof(float));
    return used + 4096;
}

LS_EXPORT("live_bytes")
int live_bytes(int sr) { return layout_bytes(sr); }

static double ls_sin(double x) {
    const double pi = 3.14159265358979323846;
    const double half = 1.57079632679489661923;
    int neg = 0;
    double x2, s;
    while (x > pi) x -= 2.0 * pi;
    while (x < -pi) x += 2.0 * pi;
    if (x < 0) { neg = 1; x = -x; }
    if (x > half) x = pi - x;
    x2 = x * x;
    s = x * (1.0 + x2 * (-1.0 / 6.0 + x2 * (1.0 / 120.0 + x2 * (-1.0 / 5040.0
        + x2 * (1.0 / 362880.0 + x2 * (-1.0 / 39916800.0
        + x2 * (1.0 / 6227020800.0)))))));
    return neg ? -s : s;
}

static double ls_cos(double x) {
    return ls_sin(x + 1.57079632679489661923);
}

static double ls_exp(double x) {
    const double ln2 = 0.693147180559945309417;
    int n, i;
    double nd, f, f2, p, s;
    if (x > 40.0) x = 40.0;
    if (x < -40.0) return 0.0;
    nd = x / ln2;
    n = (int)(nd + (nd < 0.0 ? -0.5 : 0.5));
    f = x - (double)n * ln2;
    f2 = f * f;
    p = 1.0 + f + f2 * (0.5 + f * (1.0 / 6.0 + f * (1.0 / 24.0 + f * (1.0 / 120.0
        + f * (1.0 / 720.0 + f * (1.0 / 5040.0 + f * (1.0 / 40320.0
        + f * (1.0 / 362880.0 + f / 3628800.0))))))));
    s = 1.0;
    if (n >= 0) {
        for (i = 0; i < n; i++) s *= 2.0;
    } else {
        for (i = 0; i < -n; i++) s *= 0.5;
    }
    return s * p;
}

static double soft_limit(double x) {
    double a, u, e, th;
    a = x < 0.0 ? -x : x;
    if (a <= 0.95) return x;
    u = (a - 0.95) * 20.0;
    if (u > 16.0) return x < 0.0 ? -0.999 : 0.999;
    e = ls_exp(-2.0 * u);
    th = (1.0 - e) / (1.0 + e);
    return (x < 0.0 ? -1.0 : 1.0) * (0.95 + 0.05 * th);
}

LS_EXPORT("live_soft")
float live_soft(float x) { return (float)soft_limit((double)x); }

static int finite_d(double x) {
    if (x != x) return 0;
    if (x > 1.0e30 || x < -1.0e30) return 0;
    return 1;
}

#if defined(__wasm_simd128__)
#include <wasm_simd128.h>
#define LS_SIMD 1
#elif defined(_M_X64) || defined(__SSE2__)
#include <immintrin.h>
#define LS_SIMD 1
#endif

static void init_twiddles(void) {
    int k;
    if (g_wready) return;
    for (k = 0; k < FFTN; k++) {
        double ang = -2.0 * 3.14159265358979323846 * (double)k / (double)FFTN;
        g_wre[k] = (float)ls_cos(ang);
        g_wim[k] = (float)ls_sin(ang);
    }
    g_wready = 1;
}

static void fft_complex(float *re, float *im, int inv) {
    int i, j, bit, len, half, step, u, v;
    for (i = 1, j = 0; i < FFTN; i++) {
        bit = FFTN >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) {
            float tr = re[i]; re[i] = re[j]; re[j] = tr;
            float ti = im[i]; im[i] = im[j]; im[j] = ti;
        }
    }
    for (len = 2; len <= FFTN; len <<= 1) {
        half = len >> 1;
        step = FFTN / len;
        for (i = 0; i < FFTN; i += len) {
            j = 0;
#if defined(LS_SIMD)
            for (; j + 4 <= half; j += 4) {
                LS_ALIGN16 float wrv[4], wiv[4];
                int k;
                for (k = 0; k < 4; k++) {
                    int tw = (j + k) * step;
                    wrv[k] = g_wre[tw];
                    wiv[k] = inv ? -g_wim[tw] : g_wim[tw];
                }
                u = i + j;
#if defined(__wasm_simd128__)
                {
                    v128_t vre = wasm_v128_load(re + u + half);
                    v128_t vim = wasm_v128_load(im + u + half);
                    v128_t vwr = wasm_f32x4_make(wrv[0], wrv[1], wrv[2], wrv[3]);
                    v128_t vwi = wasm_f32x4_make(wiv[0], wiv[1], wiv[2], wiv[3]);
                    v128_t tr = wasm_f32x4_sub(wasm_f32x4_mul(vwr, vre), wasm_f32x4_mul(vwi, vim));
                    v128_t ti = wasm_f32x4_add(wasm_f32x4_mul(vwr, vim), wasm_f32x4_mul(vwi, vre));
                    v128_t ure = wasm_v128_load(re + u);
                    v128_t uim = wasm_v128_load(im + u);
                    wasm_v128_store(re + u + half, wasm_f32x4_sub(ure, tr));
                    wasm_v128_store(im + u + half, wasm_f32x4_sub(uim, ti));
                    wasm_v128_store(re + u, wasm_f32x4_add(ure, tr));
                    wasm_v128_store(im + u, wasm_f32x4_add(uim, ti));
                }
#else
                {
                    __m128 vre = _mm_loadu_ps(re + u + half);
                    __m128 vim = _mm_loadu_ps(im + u + half);
                    __m128 vwr = _mm_load_ps(wrv);
                    __m128 vwi = _mm_load_ps(wiv);
                    __m128 tr = _mm_sub_ps(_mm_mul_ps(vwr, vre), _mm_mul_ps(vwi, vim));
                    __m128 ti = _mm_add_ps(_mm_mul_ps(vwr, vim), _mm_mul_ps(vwi, vre));
                    __m128 ure = _mm_loadu_ps(re + u);
                    __m128 uim = _mm_loadu_ps(im + u);
                    _mm_storeu_ps(re + u + half, _mm_sub_ps(ure, tr));
                    _mm_storeu_ps(im + u + half, _mm_sub_ps(uim, ti));
                    _mm_storeu_ps(re + u, _mm_add_ps(ure, tr));
                    _mm_storeu_ps(im + u, _mm_add_ps(uim, ti));
                }
#endif
            }
#endif
            for (; j < half; j++) {
                int tw = j * step;
                float wr = g_wre[tw];
                float wi = inv ? -g_wim[tw] : g_wim[tw];
                u = i + j;
                v = u + half;
                {
                    float tr = wr * re[v] - wi * im[v];
                    float ti = wr * im[v] + wi * re[v];
                    re[v] = re[u] - tr;
                    im[v] = im[u] - ti;
                    re[u] += tr;
                    im[u] += ti;
                }
            }
        }
    }
    if (inv) {
        float s = 1.0f / (float)FFTN;
        for (i = 0; i < FFTN; i++) { re[i] *= s; im[i] *= s; }
    }
}

static void *take(unsigned char *base, int *used, int bytes) {
    int u = align_up(*used);
    void *p = base + u;
    *used = u + bytes;
    return p;
}

static void wire_defaults(LiveStereo *st) {
    int b, i;
    for (b = 0; b < 3; b++) {
        st->directIdx[b] = -1;
        st->directBIdx[b] = -1;
        st->micG[b] = 1.0;
        st->micPh[b] = 1.0;
        for (i = 0; i < N; i++) st->fdnIdx[b][i] = -1;
    }
    st->micPan[0] = -1.0;
    st->micPan[1] = 0.0;
    st->micPan[2] = 1.0;
    for (b = 0; b < 2; b++) {
        for (i = 0; i < N; i++) {
            st->earlyIdx[b][i] = -2;
            st->earlyBIdx[b][i] = -2;
        }
    }
    st->g = 0.03;
    st->fdn_wet = 1.0;
    st->direct_wet = 1.0;
    st->gain_a = 1.0;
    st->gain_b = 1.0;
    st->makeup = 1.0;
    for (b = 0; b < 3; b++) {
        st->bus[b].dirGain = 1.0;
        st->bus[b].dirGainB = 1.0;
        st->bus[b].dirD = 64.0;
        st->bus[b].dirDT = 64.0;
        st->bus[b].dirDB = 64.0;
        st->bus[b].dirDBT = 64.0;
        for (i = 0; i < N; i++) {
            st->bus[b].line[i].delay = 64.0;
            st->bus[b].line[i].delayT = 64.0;
            st->bus[b].line[i].delayB = 64.0;
            st->bus[b].line[i].delayBT = 64.0;
            st->bus[b].line[i].sb0 = 1.0;
            st->bus[b].line[i].sb0b = 1.0;
        }
    }
}

LS_EXPORT("live_bind")
LiveStereo *live_bind(void *mem, int bytes, int sr) {
    unsigned char *base;
    int used, cap, slabN, specN, fdlN, b, i;
    LiveStereo *st;
    float *p;
    if (!mem || bytes < (int)sizeof(LiveStereo) + 1024) return 0;
    if (sr < 8000) sr = 48000;
    if (bytes < layout_bytes(sr)) return 0;
    /* Caller memory is already clear: wasm memory.grow, or a zeroed test buffer.
     * Wiping the whole delay slab here blocks the audio thread long enough to kill Play. */
    ls_zero(mem, (int)sizeof(LiveStereo));
    base = (unsigned char *)mem;
    st = (LiveStereo *)mem;
    used = (int)sizeof(LiveStereo);
    cap = cap_for(sr);
    slabN = 3 * (2 + N * 4) * cap;
    st->slab = (float *)take(base, &used, slabN * (int)sizeof(float));
    st->slabN = slabN;
    specN = MAX_IRS * MAX_PART * FFTN;
    st->specRe = (float *)take(base, &used, specN * (int)sizeof(float));
    st->specIm = (float *)take(base, &used, specN * (int)sizeof(float));
    fdlN = MAX_FILT * MAX_PART * FFTN;
    st->fdlRe = (float *)take(base, &used, fdlN * (int)sizeof(float));
    st->fdlIm = (float *)take(base, &used, fdlN * (int)sizeof(float));
    st->blob = (float *)take(base, &used, MAX_BLOB * (int)sizeof(float));
    st->irScratch = (float *)take(base, &used, MAX_IR_FLOATS * (int)sizeof(float));
    st->lenScratch = (int *)take(base, &used, MAX_IRS * (int)sizeof(int));
    st->routeScratch = (int *)take(base, &used, ROUTE_LEN * (int)sizeof(int));
    st->inL = (float *)take(base, &used, MAX_AUDIO * (int)sizeof(float));
    st->inR = (float *)take(base, &used, MAX_AUDIO * (int)sizeof(float));
    st->outL = (float *)take(base, &used, MAX_AUDIO * (int)sizeof(float));
    st->outR = (float *)take(base, &used, MAX_AUDIO * (int)sizeof(float));
    if (used > bytes) return 0;
    st->sr = sr;
    st->cap = cap;
    st->maxDelay = cap - RING_GUARD;
    if (st->maxDelay < 256) st->maxDelay = 256;
    p = st->slab;
    for (b = 0; b < 3; b++) {
        st->dir[b] = p; p += cap;
        st->dirB[b] = p; p += cap;
        for (i = 0; i < N; i++) {
            st->ring[b][i] = p;
            p += cap * LANES;
        }
    }
    wire_defaults(st);
    init_twiddles();
    st->magic = 0x2011;
    st->ready = 1;
    return st;
}

LS_EXPORT("live_blob_ptr") float *live_blob_ptr(LiveStereo *st) { return st ? st->blob : 0; }
LS_EXPORT("live_ir_ptr") float *live_ir_ptr(LiveStereo *st) { return st ? st->irScratch : 0; }
LS_EXPORT("live_len_ptr") int *live_len_ptr(LiveStereo *st) { return st ? st->lenScratch : 0; }
LS_EXPORT("live_route_ptr") int *live_route_ptr(LiveStereo *st) { return st ? st->routeScratch : 0; }
LS_EXPORT("live_in_l") float *live_in_l(LiveStereo *st) { return st ? st->inL : 0; }
LS_EXPORT("live_in_r") float *live_in_r(LiveStereo *st) { return st ? st->inR : 0; }
LS_EXPORT("live_out_l") float *live_out_l(LiveStereo *st) { return st ? st->outL : 0; }
LS_EXPORT("live_out_r") float *live_out_r(LiveStereo *st) { return st ? st->outR : 0; }

static double clampf(double x, double lo, double hi) {
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}

static double ms_to_delay(LiveStereo *st, double ms) {
    double d;
    if (!(ms > 0.0)) ms = 20.0;
    d = ms * 0.001 * (double)st->sr;
    if (d < 2.0) d = 2.0;
    if (d > (double)st->maxDelay) d = (double)st->maxDelay;
    return d;
}

static void clear_b(LiveStereo *st) {
    int b, i;
    for (b = 0; b < 3; b++) {
        Bus *bus = &st->bus[b];
        ls_zero(st->dirB[b], st->cap * (int)sizeof(float));
        bus->dirWB = 0;
        for (i = 0; i < N; i++) {
            Line *line = &bus->line[i];
            int t;
            float *ring = st->ring[b][i];
            for (t = 0; t < st->cap; t++) {
                ring[t * LANES + LANE_FDNB] = 0;
                ring[t * LANES + LANE_EARLYB] = 0;
            }
            line->pz1b = 0; line->pz2b = 0;
            line->airZe = 0; line->sz1e = 0; line->sz2e = 0;
            line->airZb = 0; line->sz1b = 0; line->sz2b = 0;
            line->airZf = 0; line->sz1f = 0; line->sz2f = 0;
            bus->fb[i] = 0;
            bus->fbB[i] = 0;
        }
    }
    for (i = 0; i < MAX_FILT; i++) {
        if (st->filt[i].used && st->filt[i].kind == 2) {
            st->filt[i].used = 0;
            st->filt[i].cold = MAX_PART;
        }
    }
}

typedef struct Rd { const float *p; int i, n; } Rd;
static double rf(Rd *r) {
    if (r->i >= r->n) return 0.0;
    return (double)r->p[r->i++];
}

static void load_shelf(Rd *r, Line *line, int bankB) {
    int on = rf(r) > 0.5;
    double b0 = rf(r), b1 = rf(r), b2 = rf(r), a1 = rf(r), a2 = rf(r);
    if (bankB) {
        line->shelfOnB = on;
        if (on) {
            line->sb0b = b0; line->sb1b = b1; line->sb2b = b2;
            line->sa1b = a1; line->sa2b = a2;
        }
    } else {
        line->shelfOn = on;
        if (on) {
            line->sb0 = b0; line->sb1 = b1; line->sb2 = b2;
            line->sa1 = a1; line->sa2 = a2;
        }
    }
}

LS_EXPORT("live_load_room")
void live_load_room(LiveStereo *st, int n) {
    Rd r;
    int b, i, nextTwo, snap, maxMs;
    double d;
    if (!st || st->magic != 0x2011 || n < 16) return;
    if (n > MAX_BLOB) n = MAX_BLOB;
    r.p = st->blob; r.i = 0; r.n = n;
    if ((int)rf(&r) != 1) return;
    d = rf(&r); if (finite_d(d)) st->g = d;
    st->fdn_wet = rf(&r);
    st->direct_wet = rf(&r);
    st->early_wet = rf(&r);
    st->dry_gain = rf(&r);
    st->makeup = rf(&r);
    st->gain_a = clampf(rf(&r), 0.0, 1.0);
    st->gain_b = clampf(rf(&r), 0.0, 1.0);
    nextTwo = rf(&r) > 0.5;
    st->colour_on = rf(&r) > 0.5;
    st->mono = rf(&r) > 0.5;
    st->direct_index = (int)rf(&r);
    if (st->direct_index < 0) st->direct_index = 0;
    if (st->direct_index > N - 1) st->direct_index = N - 1;
    maxMs = (int)(rf(&r) + 0.5);
    if (maxMs < 1) maxMs = 1000;
    d = (double)st->sr * (double)maxMs * 0.001;
    st->maxDelay = (int)(d + 0.5);
    if (st->maxDelay < 256) st->maxDelay = 256;
    if (st->maxDelay > st->cap - RING_GUARD) st->maxDelay = st->cap - RING_GUARD;
    snap = rf(&r) > 0.5;
    (void)rf(&r);
    for (b = 0; b < 3; b++) {
        st->micG[b] = clampf(rf(&r), 0.0, 16.0);
        st->micPan[b] = clampf(rf(&r), -1.0, 1.0);
        st->micPh[b] = rf(&r) < 0.0 ? -1.0 : 1.0;
    }
    for (b = 0; b < 3; b++) {
        int on = rf(&r) > 0.5;
        st->peakOn[b] = on;
        st->pb0[b] = rf(&r); st->pb1[b] = rf(&r); st->pb2[b] = rf(&r);
        st->pa1[b] = rf(&r); st->pa2[b] = rf(&r);
        if (!on) {
            int bb, j;
            for (bb = 0; bb < 3; bb++) {
                for (j = 0; j < N; j++) {
                    if ((j % 3) == b) {
                        st->bus[bb].line[j].pz1 = 0;
                        st->bus[bb].line[j].pz2 = 0;
                        st->bus[bb].line[j].pz1b = 0;
                        st->bus[bb].line[j].pz2b = 0;
                    }
                }
            }
        }
    }
    if (nextTwo && !st->two) clear_b(st);
    st->two = nextTwo;
    for (b = 0; b < 3; b++) {
        Bus *bus = &st->bus[b];
        int any = 0, anyB = 0;
        double airLp;
        for (i = 0; i < N; i++) {
            Line *line = &bus->line[i];
            line->delayT = ms_to_delay(st, rf(&r));
            if (snap) line->delay = line->delayT;
        }
        for (i = 0; i < N; i++) bus->line[i].inj = rf(&r);
        for (i = 0; i < N; i++) {
            bus->line[i].dffs = clampf(rf(&r), -0.98, 0.98);
            if (bus->line[i].dffs > 1.0e-12 || bus->line[i].dffs < -1.0e-12) any = 1;
        }
        for (i = 0; i < N; i++) bus->line[i].airG = rf(&r);
        airLp = rf(&r);
        for (i = 0; i < N; i++) {
            bus->line[i].airLp = airLp;
            load_shelf(&r, &bus->line[i], 0);
        }
        bus->dirDT = ms_to_delay(st, rf(&r));
        if (snap) bus->dirD = bus->dirDT;
        bus->dirGain = clampf(rf(&r), -2.0, 2.0);
        bus->anyDffs = any;
        for (i = 0; i < N; i++) {
            bus->line[i].delayBT = ms_to_delay(st, rf(&r));
            if (snap) bus->line[i].delayB = bus->line[i].delayBT;
        }
        for (i = 0; i < N; i++) bus->line[i].injB = rf(&r);
        for (i = 0; i < N; i++) {
            bus->line[i].dffsB = clampf(rf(&r), -0.98, 0.98);
            if (bus->line[i].dffsB > 1.0e-12 || bus->line[i].dffsB < -1.0e-12) anyB = 1;
        }
        for (i = 0; i < N; i++) bus->line[i].airGb = rf(&r);
        (void)rf(&r);
        for (i = 0; i < N; i++) load_shelf(&r, &bus->line[i], 1);
        bus->dirDBT = ms_to_delay(st, rf(&r));
        if (snap) bus->dirDB = bus->dirDBT;
        bus->dirGainB = clampf(rf(&r), -2.0, 2.0);
        bus->anyDffsB = anyB;
    }
}

static void zero_filts(LiveStereo *st) {
    int i;
    int n = MAX_FILT * MAX_PART * FFTN;
    ls_zero(st->fdlRe, n * (int)sizeof(float));
    ls_zero(st->fdlIm, n * (int)sizeof(float));
    for (i = 0; i < MAX_FILT; i++) {
        ls_zero(st->filt[i].prev, PART * (int)sizeof(float));
        st->filt[i].pos = 0;
        st->filt[i].cold = MAX_PART;
    }
}

static void design_ir(LiveStereo *st, int ir, const float *src, int len) {
    int p, npart, i, base;
    if (len < 1) len = 1;
    if (len > 8192) len = 8192;
    npart = (len + PART - 1) / PART;
    if (npart > MAX_PART) npart = MAX_PART;
    st->irLen[ir] = len;
    st->irNpart[ir] = npart;
    base = ir * MAX_PART * FFTN;
    ls_zero(st->specRe + base, MAX_PART * FFTN * (int)sizeof(float));
    ls_zero(st->specIm + base, MAX_PART * FFTN * (int)sizeof(float));
    for (p = 0; p < npart; p++) {
        int off = p * PART;
        int n = len - off;
        if (n > PART) n = PART;
        if (n < 0) n = 0;
        for (i = 0; i < FFTN; i++) { g_re[i] = 0; g_im[i] = 0; }
        for (i = 0; i < n; i++) g_re[i] = src[off + i];
        fft_complex(g_re, g_im, 0);
        ls_copy(st->specRe + base + p * FFTN, g_re, FFTN * (int)sizeof(float));
        ls_copy(st->specIm + base + p * FFTN, g_im, FFTN * (int)sizeof(float));
    }
}

LS_EXPORT("live_load_irs")
void live_load_irs(LiveStereo *st, int nIrs) {
    int i, o;
    if (!st || st->magic != 0x2011) return;
    if (nIrs < 0) nIrs = 0;
    if (nIrs > MAX_IRS) nIrs = MAX_IRS;
    o = 0;
    for (i = 0; i < nIrs; i++) {
        int len = st->lenScratch[i];
        if (len < 0) len = 0;
        if (o + len > MAX_IR_FLOATS) len = MAX_IR_FLOATS - o;
        if (len < 0) len = 0;
        design_ir(st, i, st->irScratch + o, len);
        o += len;
    }
    st->n_irs = nIrs;
    zero_filts(st);
}

LS_EXPORT("live_load_route")
void live_load_route(LiveStereo *st) {
    int o, b, i;
    const int *r;
    if (!st || st->magic != 0x2011) return;
    r = st->routeScratch;
    o = 0;
    for (b = 0; b < 3; b++) {
        for (i = 0; i < N; i++) st->fdnIdx[b][i] = r[o++];
    }
    for (b = 0; b < 2; b++) {
        for (i = 0; i < N; i++) st->earlyIdx[b][i] = r[o++];
    }
    for (b = 0; b < 2; b++) {
        for (i = 0; i < N; i++) st->earlyBIdx[b][i] = r[o++];
    }
    for (b = 0; b < 3; b++) st->directIdx[b] = r[o++];
    for (b = 0; b < 3; b++) st->directBIdx[b] = r[o++];
}

LS_EXPORT("live_force_delay")
void live_force_delay(LiveStereo *st, float samples) {
    double d;
    int b, i;
    if (!st || st->magic != 0x2011) return;
    d = (double)samples;
    if (d < 2.0) d = 2.0;
    if (d > (double)st->maxDelay) d = (double)st->maxDelay;
    for (b = 0; b < 3; b++) {
        st->bus[b].dirD = d;
        st->bus[b].dirDT = d;
        st->bus[b].dirDB = d;
        st->bus[b].dirDBT = d;
        for (i = 0; i < N; i++) {
            st->bus[b].line[i].delay = d;
            st->bus[b].line[i].delayT = d;
            st->bus[b].line[i].delayB = d;
            st->bus[b].line[i].delayBT = d;
        }
    }
}

LS_EXPORT("live_probe")
float live_probe(LiveStereo *st, int bus, int line, int which, int back) {
    float *bptr;
    int w, i, lane;
    if (!st || st->magic != 0x2011) return 0;
    if (bus < 0 || bus > 2) return 0;
    if (line < 0) line = 0;
    if (line > N - 1) line = N - 1;
    if (which == 4) { bptr = st->dir[bus]; w = st->bus[bus].dirW; lane = -1; }
    else if (which == 5) { bptr = st->dirB[bus]; w = st->bus[bus].dirWB; lane = -1; }
    else {
        w = st->bus[bus].line[line].w;
        bptr = st->ring[bus][line];
        if (which == 1) lane = LANE_FDNB;
        else if (which == 2) lane = LANE_EARLY;
        else if (which == 3) lane = LANE_EARLYB;
        else lane = LANE_FDN;
    }
    i = w - 1 - back;
    while (i < 0) i += st->cap;
    while (i >= st->cap) i -= st->cap;
    if (lane < 0) return bptr[i];
    return bptr[i * LANES + lane];
}

static void write_lane(float *ring, int w, int lane, float v) {
    ring[w * LANES + lane] = v;
}

static double read_lane(const float *ring, int lane, int w, double delay, int cap) {
    double r, frac, a, b;
    int i0, i1;
    r = (double)w - delay;
    if (r < 0.0) r += (double)cap;
    if (r >= (double)cap) r -= (double)cap;
    if (r < 0.0) r = 0.0;
    i0 = (int)r;
    if (i0 >= cap) i0 = 0;
    if (i0 < 0) i0 = 0;
    frac = r - (double)i0;
    if (frac < 0.0) frac = 0.0;
    else if (frac > 1.0) frac = 1.0;
    i1 = i0 + 1;
    if (i1 >= cap) i1 = 0;
    a = (double)ring[i0 * LANES + lane];
    b = (double)ring[i1 * LANES + lane];
    return a + frac * (b - a);
}

static double read_lin(const float *buf, int w, double delay, int cap) {
    double r, frac, a, b;
    int i0, i1;
    r = (double)w - delay;
    if (r < 0.0) r += (double)cap;
    if (r >= (double)cap) r -= (double)cap;
    if (r < 0.0) r = 0.0;
    i0 = (int)r;
    if (i0 >= cap) i0 = 0;
    if (i0 < 0) i0 = 0;
    frac = r - (double)i0;
    if (frac < 0.0) frac = 0.0;
    else if (frac > 1.0) frac = 1.0;
    i1 = i0 + 1;
    if (i1 >= cap) i1 = 0;
    a = (double)buf[i0];
    b = (double)buf[i1];
    return a + frac * (b - a);
}

static void adv(int *w, int cap) {
    int n = *w + 1;
    if (n >= cap) n = 0;
    *w = n;
}

static void fwht(double *a) {
    int len, step, i, j;
    for (len = 1; len < N; len = step) {
        step = len << 1;
        for (i = 0; i < N; i += step) {
            for (j = 0; j < len; j++) {
                double u = a[i + j];
                double v = a[i + j + len];
                a[i + j] = u + v;
                a[i + j + len] = u - v;
            }
        }
    }
}

static double tint(Line *line, double xin, int kind) {
    double g, z, lp, b0, b1, b2, a1, a2, s1, s2, yi;
    int on;
    lp = line->airLp;
    if (kind == 3) {
        g = line->airGb; z = line->airZf; on = line->shelfOnB;
        b0 = line->sb0b; b1 = line->sb1b; b2 = line->sb2b;
        a1 = line->sa1b; a2 = line->sa2b; s1 = line->sz1f; s2 = line->sz2f;
    } else if (kind == 2) {
        g = line->airGb; z = line->airZb; on = line->shelfOnB;
        b0 = line->sb0b; b1 = line->sb1b; b2 = line->sb2b;
        a1 = line->sa1b; a2 = line->sa2b; s1 = line->sz1b; s2 = line->sz2b;
    } else if (kind == 1) {
        g = line->airG; z = line->airZe; on = line->shelfOn;
        b0 = line->sb0; b1 = line->sb1; b2 = line->sb2;
        a1 = line->sa1; a2 = line->sa2; s1 = line->sz1e; s2 = line->sz2e;
    } else {
        g = line->airG; z = line->airZ; on = line->shelfOn;
        b0 = line->sb0; b1 = line->sb1; b2 = line->sb2;
        a1 = line->sa1; a2 = line->sa2; s1 = line->sz1; s2 = line->sz2;
    }
    if (lp > 0.0 && g > 0.0) {
        z += g * (xin - z);
        xin = (1.0 - lp) * xin + lp * z;
    }
    if (on) {
        yi = b0 * xin + s1;
        s1 = b1 * xin - a1 * yi + s2;
        s2 = b2 * xin - a2 * yi;
        xin = yi;
    }
    if (kind == 3) { line->airZf = z; line->sz1f = s1; line->sz2f = s2; }
    else if (kind == 2) { line->airZb = z; line->sz1b = s1; line->sz2b = s2; }
    else if (kind == 1) { line->airZe = z; line->sz1e = s1; line->sz2e = s2; }
    else { line->airZ = z; line->sz1 = s1; line->sz2 = s2; }
    return xin;
}

static double read_peaked(LiveStereo *st, Line *line, const float *ring, int lane, int i, int bankB, double delay) {
    double v, yi, nz1, nz2;
    int ax = i % 3;
    double *z1, *z2;
    v = read_lane(ring, lane, line->w, delay, st->cap);
    if (!st->peakOn[ax]) return v;
    z1 = bankB ? &line->pz1b : &line->pz1;
    z2 = bankB ? &line->pz2b : &line->pz2;
    yi = st->pb0[ax] * v + *z1;
    nz1 = st->pb1[ax] * v - st->pa1[ax] * yi + *z2;
    nz2 = st->pb2[ax] * v - st->pa2[ax] * yi;
    *z1 = nz1;
    *z2 = nz2;
    return yi;
}

static void diffuse(LiveStereo *st, int b, int bankB, const double *xin, double *fb, double *yOut) {
    Bus *bus = &st->bus[b];
    int i;
    double g;
    for (i = 0; i < N; i++) {
        Line *line = &bus->line[i];
        double gi = bankB ? line->dffsB : line->dffs;
        double s = xin[i] + fb[i];
        double y = -gi * s + st->delayed[i];
        write_lane(st->ring[b][i], line->w, bankB ? LANE_FDNB : LANE_FDN, (float)(s + gi * y));
        yOut[i] = y;
        st->reads[i] = y;
    }
    fwht(st->reads);
    g = st->g;
    for (i = 0; i < N; i++) fb[i] = g * st->reads[i];
}

static void bus_sample(LiveStereo *st, int b, double x, double xA, double xB, int two, int t) {
    Bus *bus = &st->bus[b];
    int i, cap = st->cap;
    int runFdn = st->fdn_wet > 1.0e-4;
    int runEarly = st->early_wet > 1.0e-4;
    double dA, dB = 0.0, early = 0.0;
    for (i = 0; i < N; i++) {
        Line *line = &bus->line[i];
        line->delay += SMOOTH * (line->delayT - line->delay);
        if (two) line->delayB += SMOOTH * (line->delayBT - line->delayB);
    }
    bus->dirD += SMOOTH * (bus->dirDT - bus->dirD);
    dA = read_lin(st->dir[b], bus->dirW, bus->dirD, cap);
    /* One source stores the raw downmix. Two sources scale by that source's spike. */
    st->dir[b][bus->dirW] = (float)(two ? xA * bus->dirGain : x);
    adv(&bus->dirW, cap);
    if (two) {
        bus->dirDB += SMOOTH * (bus->dirDBT - bus->dirDB);
        dB = read_lin(st->dirB[b], bus->dirWB, bus->dirDB, cap);
        st->dirB[b][bus->dirWB] = (float)(xB * bus->dirGainB);
        adv(&bus->dirWB, cap);
    }
    st->daBlk[b][t] = dA;
    st->dbBlk[b][t] = dB;

    if (!two) {
        int mix1 = runFdn && bus->anyDffs;
        if (runFdn && !mix1) {
            for (i = 0; i < N; i++) {
                st->delayed[i] = read_peaked(st, &bus->line[i], st->ring[b][i], LANE_FDN, i, 0, bus->line[i].delay);
                st->reads[i] = st->delayed[i];
            }
            fwht(st->reads);
        } else if (mix1) {
            for (i = 0; i < N; i++) {
                st->delayed[i] = read_peaked(st, &bus->line[i], st->ring[b][i], LANE_FDN, i, 0, bus->line[i].delay);
            }
        }
        for (i = 0; i < N; i++) {
            Line *line = &bus->line[i];
            double xin = 0.0;
            if (runEarly || runFdn) xin = tint(line, x * line->inj, 0);
            if (runEarly) {
                double ev = read_lane(st->ring[b][i], LANE_EARLY, line->w, line->delay, cap);
                write_lane(st->ring[b][i], line->w, LANE_EARLY, (float)xin);
                st->eaBlk[b][i][t] = ev;
                early += ev;
            }
            if (mix1) st->xinArr[i] = xin;
            else if (runFdn) {
                double gi = line->dffs;
                double mixed = st->g * st->reads[i] + xin;
                double y = -gi * mixed + st->delayed[i];
                write_lane(st->ring[b][i], line->w, LANE_FDN, (float)(mixed + gi * y));
                st->yBlk[b][i][t] = y;
            }
            if (!mix1) adv(&line->w, cap);
        }
        if (mix1) {
            diffuse(st, b, 0, st->xinArr, bus->fb, st->yA);
            for (i = 0; i < N; i++) {
                st->yBlk[b][i][t] = st->yA[i];
                adv(&bus->line[i].w, cap);
            }
        }
        st->esBlk[b][t] = early;
        return;
    }

    if (runEarly) {
        for (i = 0; i < N; i++) {
            Line *line = &bus->line[i];
            double ev = read_lane(st->ring[b][i], LANE_EARLY, line->w, line->delay, cap);
            double evB = read_lane(st->ring[b][i], LANE_EARLYB, line->w, line->delayB, cap);
            write_lane(st->ring[b][i], line->w, LANE_EARLY, (float)tint(line, xA * line->inj, 1));
            write_lane(st->ring[b][i], line->w, LANE_EARLYB, (float)tint(line, xB * line->injB, 2));
            st->eaBlk[b][i][t] = ev;
            st->ebBlk[b][i][t] = evB;
            early += ev + evB;
        }
    }
    if (runFdn) {
        int mixA = bus->anyDffs;
        int mixB = bus->anyDffsB;
        for (i = 0; i < N; i++) {
            Line *line = &bus->line[i];
            st->delayed[i] = read_peaked(st, line, st->ring[b][i], LANE_FDN, i, 0, line->delay);
            st->reads[i] = st->delayed[i];
            st->xinArr[i] = tint(line, 0.5 * xA * line->inj, 0);
        }
        if (mixA) diffuse(st, b, 0, st->xinArr, bus->fb, st->yA);
        else {
            fwht(st->reads);
            for (i = 0; i < N; i++) {
                Line *line = &bus->line[i];
                double gi = line->dffs;
                double mixed = st->g * st->reads[i] + st->xinArr[i];
                double y = -gi * mixed + st->delayed[i];
                write_lane(st->ring[b][i], line->w, LANE_FDN, (float)(mixed + gi * y));
                st->yA[i] = y;
            }
        }
        for (i = 0; i < N; i++) {
            Line *line = &bus->line[i];
            st->delayed[i] = read_peaked(st, line, st->ring[b][i], LANE_FDNB, i, 1, line->delayB);
            st->reads[i] = st->delayed[i];
            st->xinArr[i] = tint(line, 0.5 * xB * line->injB, 3);
        }
        if (mixB) {
            diffuse(st, b, 1, st->xinArr, bus->fbB, st->yB);
            for (i = 0; i < N; i++) st->yBlk[b][i][t] = st->yB[i] + st->yA[i];
        } else {
            fwht(st->reads);
            for (i = 0; i < N; i++) {
                Line *line = &bus->line[i];
                double gi = line->dffsB;
                double mixed = st->g * st->reads[i] + st->xinArr[i];
                double y = -gi * mixed + st->delayed[i];
                write_lane(st->ring[b][i], line->w, LANE_FDNB, (float)(mixed + gi * y));
                st->yBlk[b][i][t] = y + st->yA[i];
            }
        }
    }
    for (i = 0; i < N; i++) adv(&bus->line[i].w, cap);
    st->esBlk[b][t] = early;
}

static void scrub(LiveStereo *st) {
    int b, i;
    ls_zero(st->slab, st->slabN * (int)sizeof(float));
    for (b = 0; b < 3; b++) {
        Bus *bus = &st->bus[b];
        for (i = 0; i < N; i++) {
            Line *line = &bus->line[i];
            line->pz1 = line->pz2 = line->pz1b = line->pz2b = 0;
            line->airZ = line->airZe = line->airZb = line->airZf = 0;
            line->sz1 = line->sz2 = line->sz1e = line->sz2e = 0;
            line->sz1b = line->sz2b = line->sz1f = line->sz2f = 0;
            bus->fb[i] = 0;
            bus->fbB[i] = 0;
        }
    }
    zero_filts(st);
}

static int early_target(const int *fdnIdx, int line, int earlyIdx) {
    int i;
    if (earlyIdx < -1) return -2;
    if (fdnIdx[line] == earlyIdx) return earlyIdx;
    if (earlyIdx >= 0) {
        for (i = 0; i < N; i++) if (fdnIdx[i] == earlyIdx) return earlyIdx;
    }
    if (fdnIdx[line] >= -1) return fdnIdx[line];
    return -2;
}

static Filt *take_filt(LiveStereo *st, int bus, int kind, int ir) {
    int i, freeSlot = -1;
    for (i = 0; i < MAX_FILT; i++) {
        Filt *f = &st->filt[i];
        if (f->used && f->bus == bus && f->kind == kind && f->ir == ir) {
            f->seen = 1;
            return f;
        }
        if (!f->used && freeSlot < 0) freeSlot = i;
    }
    if (freeSlot < 0) return 0;
    {
        Filt *f = &st->filt[freeSlot];
        ls_zero(f, (int)sizeof(Filt));
        f->used = 1;
        f->bus = bus;
        f->kind = kind;
        f->ir = ir;
        f->npart = st->irNpart[ir];
        if (f->npart < 1) f->npart = 1;
        f->cold = MAX_PART;
        f->seen = 1;
        {
            int fi = freeSlot;
            int nfloat = MAX_PART * FFTN;
            ls_zero(st->fdlRe + fi * nfloat, nfloat * (int)sizeof(float));
            ls_zero(st->fdlIm + fi * nfloat, nfloat * (int)sizeof(float));
        }
        return f;
    }
}

static void mac_bins(float *accR, float *accI, const float *xr, const float *xi,
                      const float *hr, const float *hi, int n) {
    int i = 0;
#if defined(__wasm_simd128__)
    if ((((unsigned long)accR | (unsigned long)accI | (unsigned long)xr |
          (unsigned long)xi | (unsigned long)hr | (unsigned long)hi) & 15ul) == 0) {
        for (; i + 4 <= n; i += 4) {
            v128_t ar = wasm_v128_load(xr + i);
            v128_t ai = wasm_v128_load(xi + i);
            v128_t br = wasm_v128_load(hr + i);
            v128_t bi = wasm_v128_load(hi + i);
            v128_t rr = wasm_f32x4_sub(wasm_f32x4_mul(ar, br), wasm_f32x4_mul(ai, bi));
            v128_t ii = wasm_f32x4_add(wasm_f32x4_mul(ar, bi), wasm_f32x4_mul(ai, br));
            wasm_v128_store(accR + i, wasm_f32x4_add(wasm_v128_load(accR + i), rr));
            wasm_v128_store(accI + i, wasm_f32x4_add(wasm_v128_load(accI + i), ii));
        }
    }
#elif defined(LS_SIMD)
    for (; i + 4 <= n; i += 4) {
        __m128 ar = _mm_loadu_ps(xr + i);
        __m128 ai = _mm_loadu_ps(xi + i);
        __m128 br = _mm_loadu_ps(hr + i);
        __m128 bi = _mm_loadu_ps(hi + i);
        __m128 rr = _mm_sub_ps(_mm_mul_ps(ar, br), _mm_mul_ps(ai, bi));
        __m128 ii = _mm_add_ps(_mm_mul_ps(ar, bi), _mm_mul_ps(ai, br));
        _mm_storeu_ps(accR + i, _mm_add_ps(_mm_loadu_ps(accR + i), rr));
        _mm_storeu_ps(accI + i, _mm_add_ps(_mm_loadu_ps(accI + i), ii));
    }
#endif
    for (; i < n; i++) {
        float ar = xr[i], ai = xi[i], br = hr[i], bi = hi[i];
        accR[i] += ar * br - ai * bi;
        accI[i] += ar * bi + ai * br;
    }
}

static void run_fir(LiveStereo *st, Filt *f, const float *in, float *out) {
    int i, p, base, npart, pos, silent;
    float *hre, *him, *xre, *xim;
    silent = 1;
    for (i = 0; i < PART; i++) {
        if (in[i] > 1.0e-12f || in[i] < -1.0e-12f) { silent = 0; break; }
    }
    if (silent && f->cold >= f->npart) {
        for (i = 0; i < PART; i++) out[i] = 0;
        return;
    }
    if (silent) f->cold += 1;
    else f->cold = 0;
    npart = f->npart;
    if (npart < 1) npart = 1;
    if (npart > MAX_PART) npart = MAX_PART;
    for (i = 0; i < PART; i++) { g_re[i] = f->prev[i]; g_im[i] = 0; }
    for (i = 0; i < PART; i++) { g_re[PART + i] = in[i]; g_im[PART + i] = 0; }
    fft_complex(g_re, g_im, 0);
    pos = f->pos;
    xre = st->fdlRe + ((f - st->filt) * MAX_PART + pos) * FFTN;
    xim = st->fdlIm + ((f - st->filt) * MAX_PART + pos) * FFTN;
    ls_copy(xre, g_re, FFTN * (int)sizeof(float));
    ls_copy(xim, g_im, FFTN * (int)sizeof(float));
    for (i = 0; i < PART; i++) f->prev[i] = in[i];
    for (i = 0; i < FFTN; i++) { g_accR[i] = 0; g_accI[i] = 0; }
    base = f->ir * MAX_PART * FFTN;
    hre = st->specRe + base;
    him = st->specIm + base;
    for (p = 0; p < npart; p++) {
        int src = pos - p;
        float *xr, *xi, *hr, *hi;
        if (src < 0) src += MAX_PART;
        xr = st->fdlRe + ((f - st->filt) * MAX_PART + src) * FFTN;
        xi = st->fdlIm + ((f - st->filt) * MAX_PART + src) * FFTN;
        hr = hre + p * FFTN;
        hi = him + p * FFTN;
        mac_bins(g_accR, g_accI, xr, xi, hr, hi, FFTN);
    }
    f->pos = pos + 1;
    if (f->pos >= MAX_PART) f->pos = 0;
    ls_copy(g_re, g_accR, FFTN * (int)sizeof(float));
    ls_copy(g_im, g_accI, FFTN * (int)sizeof(float));
    fft_complex(g_re, g_im, 1);
    for (i = 0; i < PART; i++) out[i] = g_re[PART + i];
}

static int usable_ir(LiveStereo *st, int idx) {
    if (idx < 0) return idx == -1 ? -1 : -2;
    if (idx >= st->n_irs || st->irLen[idx] < 1) return -1;
    return idx;
}

static void side(LiveStereo *st, int b, double *sl, double *sr) {
    double t, amp;
    t = (st->micPan[b] + 1.0) * 0.5;
    if (t < 0.0) t = 0.0;
    else if (t > 1.0) t = 1.0;
    amp = st->micG[b] * (st->micPh[b] < 0.0 ? -1.0 : 1.0);
    *sl = amp * (1.0 - t);
    *sr = amp * t;
}

static void fir_or_wire(LiveStereo *st, int bus, int kind, int idx, const double *in, double *out) {
    int i, u;
    float tmp[PART], y[PART];
    Filt *f;
    u = usable_ir(st, idx);
    if (u < -1) {
        for (i = 0; i < PART; i++) out[i] = 0;
        return;
    }
    if (u < 0) {
        for (i = 0; i < PART; i++) out[i] = in[i];
        return;
    }
    f = take_filt(st, bus, kind, u);
    if (!f) {
        for (i = 0; i < PART; i++) out[i] = in[i];
        return;
    }
    f->npart = st->irNpart[u];
    for (i = 0; i < PART; i++) tmp[i] = (float)in[i];
    run_fir(st, f, tmp, y);
    for (i = 0; i < PART; i++) out[i] = (double)y[i];
}

static void mix_partition(LiveStereo *st, float *outL, float *outR) {
    int b, t, i, slot;
    double accL[PART], accR[PART];
    int keep[MAX_FILT];
    for (t = 0; t < PART; t++) { accL[t] = 0; accR[t] = 0; }
    for (i = 0; i < MAX_FILT; i++) {
        keep[i] = 0;
        st->filt[i].seen = 0;
    }

    for (b = 0; b < 3; b++) {
        double sl, sr;
        side(st, b, &sl, &sr);
        if (!st->colour_on) {
            for (t = 0; t < PART; t++) {
                double sumY = 0.0;
                double direct, wet;
                for (i = 0; i < N; i++) sumY += st->yBlk[b][i][t];
                direct = st->daBlk[b][t] + st->dbBlk[b][t];
                wet = st->direct_wet * DIRECT_FOLD * direct
                    + st->makeup * (st->fdn_wet * sumY + st->early_wet * st->esBlk[b][t]);
                accL[t] += sl * wet;
                accR[t] += sr * wet;
            }
            continue;
        }
        {
            double directA[PART], directB[PART];
            double ident[PART];
            double fdnPre[PART];
            int map[MAX_IRS];
            int eiBase = (b == BUS_L) ? 0 : 1;
            for (i = 0; i < MAX_IRS; i++) map[i] = -1;
            for (t = 0; t < PART; t++) { ident[t] = 0; fdnPre[t] = 0; }
            for (slot = 0; slot < MAX_FILT; slot++) {
                for (t = 0; t < PART; t++) st->firIn[slot][t] = 0;
            }
            for (i = 0; i < N; i++) {
                int idx = usable_ir(st, st->fdnIdx[b][i]);
                Filt *f;
                if (idx >= 0) {
                    if (map[idx] < 0) {
                        f = take_filt(st, b, 0, idx);
                        if (!f) idx = -1;
                        else {
                            map[idx] = (int)(f - st->filt);
                            f->npart = st->irNpart[idx];
                            keep[map[idx]] = 1;
                        }
                    }
                    if (idx >= 0) {
                        int s = map[idx];
                        for (t = 0; t < PART; t++) {
                            st->firIn[s][t] += (float)(st->fdn_wet * st->yBlk[b][i][t]);
                        }
                        continue;
                    }
                }
                if (idx == -1) {
                    for (t = 0; t < PART; t++) ident[t] += st->fdn_wet * st->yBlk[b][i][t];
                }
            }
            if (b != BUS_C) {
                for (i = 0; i < N; i++) {
                    int tgt = early_target(st->fdnIdx[b], i, st->earlyIdx[eiBase][i]);
                    int tgtB = st->two ? early_target(st->fdnIdx[b], i, st->earlyBIdx[eiBase][i]) : -2;
                    int u = usable_ir(st, tgt);
                    int uB = usable_ir(st, tgtB);
                    if (u >= 0 && map[u] >= 0) {
                        int s = map[u];
                        for (t = 0; t < PART; t++) st->firIn[s][t] += (float)(st->early_wet * st->eaBlk[b][i][t]);
                    } else if (u == -1) {
                        for (t = 0; t < PART; t++) ident[t] += st->early_wet * st->eaBlk[b][i][t];
                    }
                    if (uB >= 0 && map[uB] >= 0) {
                        int s = map[uB];
                        for (t = 0; t < PART; t++) st->firIn[s][t] += (float)(st->early_wet * st->ebBlk[b][i][t]);
                    } else if (uB == -1) {
                        for (t = 0; t < PART; t++) ident[t] += st->early_wet * st->ebBlk[b][i][t];
                    }
                }
            }
            for (slot = 0; slot < MAX_FILT; slot++) {
                if (!keep[slot] || !st->filt[slot].used || st->filt[slot].bus != b || st->filt[slot].kind != 0) continue;
                {
                    float y[PART];
                    run_fir(st, &st->filt[slot], st->firIn[slot], y);
                    for (t = 0; t < PART; t++) fdnPre[t] += (double)y[t];
                }
            }
            for (t = 0; t < PART; t++) fdnPre[t] += ident[t];
            for (t = 0; t < PART; t++) directA[t] = st->daBlk[b][t];
            fir_or_wire(st, b, 1, st->directIdx[b], directA, directA);
            if (st->two) {
                for (t = 0; t < PART; t++) directB[t] = st->dbBlk[b][t];
                fir_or_wire(st, b, 2, st->directBIdx[b], directB, directB);
            } else {
                for (t = 0; t < PART; t++) directB[t] = 0;
            }
            for (t = 0; t < PART; t++) {
                double earlyC = (b == BUS_C) ? st->early_wet * st->esBlk[b][t] : 0.0;
                double wet = st->direct_wet * DIRECT_FOLD * (directA[t] + directB[t])
                    + st->makeup * (fdnPre[t] + earlyC);
                accL[t] += sl * wet;
                accR[t] += sr * wet;
            }
        }
    }

    if (st->colour_on) {
        for (i = 0; i < MAX_FILT; i++) {
            if (st->filt[i].used && !st->filt[i].seen) st->filt[i].used = 0;
        }
    }
    for (t = 0; t < PART; t++) {
        double yL = st->dryBlk[t] + accL[t];
        double yR = st->dryBlk[t] + accR[t];
        if (!finite_d(yL) || !finite_d(yR)) {
            scrub(st);
            for (; t < PART; t++) { outL[t] = 0; outR[t] = 0; }
            return;
        }
        outL[t] = (float)soft_limit(yL);
        outR[t] = (float)soft_limit(yR);
    }
}

static void run_partition(LiveStereo *st, const float *inL, const float *inR, float *outL, float *outR) {
    int t, b, i;
    for (b = 0; b < 3; b++) {
        for (i = 0; i < N; i++) {
            for (t = 0; t < PART; t++) {
                st->yBlk[b][i][t] = 0;
                st->eaBlk[b][i][t] = 0;
                st->ebBlk[b][i][t] = 0;
            }
        }
    }
    for (t = 0; t < PART; t++) {
        double xL = (double)inL[t];
        double xR = (double)inR[t];
        double x, xA, xB, dry;
        int split = st->two;
        if (split) {
            xA = xL * st->gain_a;
            xB = xR * st->gain_b;
            x = 0.5 * (xA + xB);
        } else {
            xA = 0;
            xB = 0;
            x = 0.5 * (xL + xR);
        }
        for (b = 0; b < 3; b++) bus_sample(st, b, x, xA, xB, split, t);
        if (st->colour_on && st->mono) dry = st->dry_gain * xL;
        else if (st->two) dry = st->dry_gain * 0.5 * (st->gain_a * xL + st->gain_b * xR);
        else dry = st->dry_gain * x;
        st->dryBlk[t] = dry;
    }
    mix_partition(st, outL, outR);
}

LS_EXPORT("live_stereo")
void live_stereo(LiveStereo *st, const float *inL, const float *inR, float *outL, float *outR, int n) {
    int inI = 0, outI = 0;
    if (!outL || !outR || n <= 0) return;
    if (!st || st->magic != 0x2011 || !st->ready || !inL || !inR) {
        int i;
        for (i = 0; i < n; i++) { outL[i] = 0; outR[i] = 0; }
        return;
    }
    while (inI < n || outI < n) {
        if (st->pendN == PART) {
            run_partition(st, st->pendL, st->pendR, st->qL, st->qR);
            st->pendN = 0;
            st->qN = PART;
            st->qAt = 0;
            continue;
        }
        if (outI < n && st->qAt < st->qN) {
            int k = st->qN - st->qAt;
            if (k > n - outI) k = n - outI;
            ls_copy(outL + outI, st->qL + st->qAt, k * (int)sizeof(float));
            ls_copy(outR + outI, st->qR + st->qAt, k * (int)sizeof(float));
            outI += k;
            st->qAt += k;
            if (st->qAt >= st->qN) { st->qN = 0; st->qAt = 0; }
            continue;
        }
        if (inI < n && st->pendN < PART) {
            int k = PART - st->pendN;
            if (k > n - inI) k = n - inI;
            ls_copy(st->pendL + st->pendN, inL + inI, k * (int)sizeof(float));
            ls_copy(st->pendR + st->pendN, inR + inI, k * (int)sizeof(float));
            st->pendN += k;
            inI += k;
            continue;
        }
        if (outI < n) {
            int i;
            for (i = outI; i < n; i++) { outL[i] = 0; outR[i] = 0; }
            break;
        }
        break;
    }
}
