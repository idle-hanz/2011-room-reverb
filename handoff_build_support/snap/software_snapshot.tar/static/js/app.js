(function () {
  "use strict";

  /* Canonical stereo mic presets (space m, toe_half_deg = L/R from forward). */
  var MIC_PRESETS = {
    ab_omni: { space: 0.80, toe_half_deg: 0, car_omni: 0, polar: ["L", "R"],
      pattern_l: "omni", pattern_c: "omni", pattern_r: "omni",
      family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
      polar_l: 0, polar_c: 0, polar_r: 0,
      yaw_l_deg: 0, yaw_c_deg: 0, yaw_r_deg: 0 },
    ab_card: { space: 0.80, toe_half_deg: 5, car_omni: 1, polar: ["L", "R"],
      pattern_l: "cardioid", pattern_c: "cardioid", pattern_r: "cardioid",
      family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
      polar_l: 0.5, polar_c: 0.5, polar_r: 0.5,
      yaw_l_deg: -5, yaw_c_deg: 0, yaw_r_deg: 5 },
    xy_90:   { space: 0.01, toe_half_deg: 45, car_omni: 1, polar: ["L", "R"],
      pattern_l: "cardioid", pattern_c: "cardioid", pattern_r: "cardioid",
      family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
      polar_l: 0.5, polar_c: 0.5, polar_r: 0.5,
      yaw_l_deg: -45, yaw_c_deg: 0, yaw_r_deg: 45 },
    xy_120:  { space: 0.01, toe_half_deg: 60, car_omni: 1, polar: ["L", "R"],
      pattern_l: "cardioid", pattern_c: "cardioid", pattern_r: "cardioid",
      family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
      polar_l: 0.5, polar_c: 0.5, polar_r: 0.5,
      yaw_l_deg: -60, yaw_c_deg: 0, yaw_r_deg: 60 },
    ortf:    { space: 0.17, toe_half_deg: 55, car_omni: 1, polar: ["L", "R"],
      pattern_l: "cardioid", pattern_c: "cardioid", pattern_r: "cardioid",
      family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
      polar_l: 0.5, polar_c: 0.5, polar_r: 0.5,
      yaw_l_deg: -55, yaw_c_deg: 0, yaw_r_deg: 55 },
    nos:     { space: 0.30, toe_half_deg: 45, car_omni: 1, polar: ["L", "R"],
      pattern_l: "cardioid", pattern_c: "cardioid", pattern_r: "cardioid",
      family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
      polar_l: 0.5, polar_c: 0.5, polar_r: 0.5,
      yaw_l_deg: -45, yaw_c_deg: 0, yaw_r_deg: 45 },
    din:     { space: 0.20, toe_half_deg: 45, car_omni: 1, polar: ["L", "R"],
      pattern_l: "cardioid", pattern_c: "cardioid", pattern_r: "cardioid",
      family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
      polar_l: 0.5, polar_c: 0.5, polar_r: 0.5,
      yaw_l_deg: -45, yaw_c_deg: 0, yaw_r_deg: 45 },
    ms:      { space: 0.05, toe_half_deg: 90, car_omni: 1, polar: ["L", "C", "R"],
      pattern_l: "cardioid", pattern_c: "omni", pattern_r: "cardioid",
      family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
      polar_l: 0.5, polar_c: 0, polar_r: 0.5,
      yaw_l_deg: -90, yaw_c_deg: 0, yaw_r_deg: 90 },
    ms_classic: { space: 0.05, toe_half_deg: 90, car_omni: 1, polar: ["L", "C", "R"],
      pattern_l: "fig8", pattern_c: "cardioid", pattern_r: "fig8",
      family_l: "bi", family_c: "cardioid", family_r: "bi",
      polar_l: 0.5, polar_c: 0.5, polar_r: 0.5,
      yaw_l_deg: -90, yaw_c_deg: 0, yaw_r_deg: 90 },
    mono_c:  { space: 0.00, toe_half_deg: 0, car_omni: 1, polar: ["C"],
      pattern_l: "cardioid", pattern_c: "cardioid", pattern_r: "cardioid",
      family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
      polar_l: 0.5, polar_c: 0.5, polar_r: 0.5,
      yaw_l_deg: 0, yaw_c_deg: 0, yaw_r_deg: 0 },
    custom:  null
  };

  function divergFromToe(toeHalfDeg) {
    /* Hidden diverg only. Reaktor: MLALR = 0.5·d − 0.25. */
    var th = -Math.abs((Number(toeHalfDeg) * Math.PI) / 180);
    return 2 * (th + 0.25);
  }

  var state = {
    W: 6, H: 3, L: 8,
    sx: 3, sz: 4.75, mcx: 3, mcz: 1.5, my: 1.5, sy: 1.5,
    link_heights: false,
    space: 0.17, diverg: 1, toe_half_deg: 55, car_omni: 1,
    pattern_l: "cardioid", pattern_c: "cardioid", pattern_r: "cardioid",
    family_l: "cardioid", family_c: "cardioid", family_r: "cardioid",
    polar_l: 0.5, polar_c: 0.5, polar_r: 0.5,
    yaw_l_deg: -55, yaw_c_deg: 0, yaw_r_deg: 55,
    centre_dz: 0, align_horizontal: true, link_lr_yaw: true,
    mic_hp_on: false, mic_hp_hz: 40, mic_response_hz: 10000, mic_proximity: 0.25,
    capsule_mm: 17, ms_decode: false,
    colour_mode: "MEASURED_SHELF",
    mic_preset_l: "ShureSM57", mic_preset_c: "ShureSM57", mic_preset_r: "ShureSM57",
    mic_hpf_engaged: false,
    mic_hpf_sides: false,
    mic_hpf_centre: false,
    preset_owns_pattern: true,
    mic_setup: "ortf",
    early_wet: 0, fdn_wet: 1, direct_wet: 1, dry_gain: 0, fdn_g: 1, ir_length_ms: 1500,
    decay_s: 1.8, decay_lock: true,
    solo_direct: false, solo_fdn: false, solo_early: false, solo_dry: false,
    stereo_mic: false, natural_bus: false,
    fader_l: 0.5, fader_c: 0.5, fader_r: 0.5,
    fader_direct: 0.5, fader_fdn: 0.5, fader_early: 0, fader_dry: 0,
    trim_l: 0, trim_c: 0, trim_r: 0,
    trim_direct: 0, trim_fdn: 0, trim_early: 0, trim_dry: 0,
    pan_l: -1, pan_c: 0, pan_r: 1,
    mute_l: false, mute_c: false, mute_r: false,
    mute_direct: false, mute_fdn: false, mute_early: false, mute_dry: false,
    phase_l: 1, phase_c: 1, phase_r: 1,
    humidity: 0.35, air_lp: 0.25, air_shelf: 1, diffusion_master: -0.5,
    reaktor_parity: false, live_drag_render: false,
    two_sources: false, mirror_b: true, source_balance: 0,
    sx_b: 3, sy_b: 1.5, sz_b: 4.75,
    path_on: false, path_preset: "still",
    ellipse_rate: 1, ellipse_rx: 0.42, ellipse_rz: 0.35,
    hadamard_n: 32,
    diffusion_seed: 0,
    lambda_ref: 0.02,
    surfaces: (window.ColourSurfacesDefaults && ColourSurfacesDefaults.defaultSurfaces)
      ? ColourSurfacesDefaults.defaultSurfaces()
      : null
  };
  var _applyingPreset = false;
  var wavFile = null;
  var wavChannels = 0;
  var currentView = "edit";
  var pathsMode = "paths"; /* paths | legs — Paths tab submode */
  var selectedMics = ["C"];
  var imagesCache = null;
  var imagesFetchTimer = null;

  var liveMetres = document.getElementById("liveMetres");
  var liveMetres3d = document.getElementById("liveMetres3d");
  var liveMetresImg = document.getElementById("liveMetresImg");
  var fileName = document.getElementById("fileName");
  var statusEl = document.getElementById("status");
  var outPathEl = document.getElementById("outPath");
  var previewAudio = document.getElementById("previewAudio");
  var renderBtn = document.getElementById("renderBtn");
  var editViews = document.getElementById("editViews");
  var micViews = document.getElementById("micViews");
  var mixViews = document.getElementById("mixViews");
  var liveMetresMic = document.getElementById("liveMetresMic");
  var imageViewsEl = document.getElementById("imageViews");
  var micToggles = document.getElementById("micToggles");
  var imageViewTitle = document.getElementById("imageViewTitle");
  var imageViewHint = document.getElementById("imageViewHint");

  var editor = RoomEditor.create({
    floorCanvas: document.getElementById("floorCanvas"),
    elevCanvas: document.getElementById("elevCanvas"),
    view3dCanvas: document.getElementById("view3dCanvas"),
    getState: function () { return state; },
    setState: function (s) { Object.assign(state, s); },
    onChange: function () { syncUI(); scheduleLiveParams(); },
    onDragEnd: function () { scheduleLiveRender(); scheduleLiveParams(); }
  });

  var imageView = null;
  var imageViewInitFailed = false;
  var syncRaf = 0;
  var imagesFetchDelayMs = 280; /* defer fetch while dragging (~drag-end) */
  var renderTimer = null;
  var renderBusy = false;
  var renderQueued = false;

  function applyReaktorSnapshot() {
    /* Locked dump 394–399 / Distances 420–435 / Humidity 486. */
    state.W = 57;
    state.H = 34.241;
    state.L = 97;
    state.sx = 24.925;
    state.sz = 72.083;
    state.sy = 1.88;
    state.my = 1.9;
    state.mcz = 24.25;
    state.space = 0.25;
    state.reaktor_parity = true;
    state.car_omni = 0.764;
    state.fader_early = 0;
    state.fader_dry = 0;
    state.fader_direct = 0.5;
    state.fader_fdn = 0.5;
    state.trim_direct = 0;
    state.trim_fdn = 0;
    state.trim_early = 0;
    state.trim_dry = 0;
    state.mute_direct = false;
    state.mute_fdn = false;
    state.mute_early = false;
    state.mute_dry = false;
    state.early_wet = 0;
    state.fdn_wet = 1;
    state.direct_wet = 1;
    state.dry_gain = 0;
    state.fdn_g = 1;
    state.decay_lock = false;
    decayFromUser = false;
    state.ir_length_ms = 1500;
    state.hadamard_n = 32;
    state.humidity = 0.5;
    state.air_lp = 0.25;
    state.air_shelf = 1;
    state.diffusion_master = -0.5;
    state.mic_response_hz = 10000;
    state.link_heights = false;
    var surfs = (window.ColourSurfacesDefaults && ColourSurfacesDefaults.defaultSurfaces)
      ? ColourSurfacesDefaults.defaultSurfaces()
      : state.surfaces;
    if (surfs) {
      var dif = { A: 0.16, B: 0.25, C: 0.16, D: 0.33, E: 0.27, F: 0.65 };
      Object.keys(dif).forEach(function (L) {
        if (surfs[L]) surfs[L].diffusion = dif[L];
      });
      state.surfaces = surfs;
    }
    if (colourSurfaces && colourSurfaces.setSurfaces) {
      colourSurfaces.setSurfaces(state.surfaces);
    }
    syncHadamardUI();
    syncUI();
    if (statusEl) {
      statusEl.textContent = "2011 snapshot loaded. Upload a WAV, then Play live or Render. Gain=1 → g=1/32, Humidity 400, hall 57×34×97.";
    }
  }

  function scheduleLiveRender() {
    if (!state.live_drag_render || !wavFile) return;
    if (renderTimer) clearTimeout(renderTimer);
    renderTimer = setTimeout(function () { doRender(); }, 420);
  }

  var liveParamsTimer = null;
  var liveBusy = false;
  var decayFromUser = false;

  var SOLO_BUSES = [
    ["solo_direct", "direct_wet", "direct"],
    ["solo_fdn", "fdn_wet", "fdn"],
    ["solo_early", "early_wet", "early"],
    ["solo_dry", "dry_gain", "dry"]
  ];

  var FADER_KNOTS = [
    [0.02, -60], [0.20, -24], [0.35, -12], [0.42, -6],
    [0.50, 0], [0.58, 3], [0.70, 6], [1, 12]
  ];

  function dbFromTravel(u) {
    u = Number(u);
    if (!(u >= 0.02)) return -Infinity;
    if (u >= 1) return 12;
    var i, a, b, t;
    for (i = 1; i < FADER_KNOTS.length; i++) {
      b = FADER_KNOTS[i];
      a = FADER_KNOTS[i - 1];
      if (u <= b[0]) {
        t = (u - a[0]) / (b[0] - a[0]);
        return a[1] + t * (b[1] - a[1]);
      }
    }
    return 12;
  }

  function travelFromDb(db) {
    if (!isFinite(db) || db < -60) return 0;
    if (db <= -60) return 0.02;
    if (db >= 12) return 1;
    var i, a, b, t;
    for (i = 1; i < FADER_KNOTS.length; i++) {
      b = FADER_KNOTS[i];
      a = FADER_KNOTS[i - 1];
      if (db <= b[1]) {
        t = (db - a[1]) / (b[1] - a[1]);
        return a[0] + t * (b[0] - a[0]);
      }
    }
    return 1;
  }

  function gainFromDb(faderDb, trimDb) {
    if (!isFinite(faderDb)) return 0;
    var db = faderDb + Number(trimDb || 0);
    if (db < -120) return 0;
    var g = Math.pow(10, db / 20);
    if (g < 0) g = 0;
    if (g > 16) g = 16;
    return g;
  }

  function formatSend(travel, trim) {
    var db = dbFromTravel(travel);
    if (!isFinite(db)) return "−∞";
    var sum = Math.round((db + Number(trim || 0)) * 10) / 10;
    return (sum > 0 ? "+" : "") + sum.toFixed(1);
  }

  function stripLinear(src, key) {
    if (src["mute_" + key]) return 0;
    return gainFromDb(dbFromTravel(src["fader_" + key]), src["trim_" + key]);
  }

  function heardMix(src) {
    var o = Object.assign({}, src);
    var buses = ["direct", "fdn", "early", "dry"];
    var i;
    o.direct_wet = stripLinear(src, "direct");
    o.fdn_wet = stripLinear(src, "fdn");
    o.early_wet = stripLinear(src, "early");
    o.dry_gain = stripLinear(src, "dry");
    var any = false;
    for (i = 0; i < SOLO_BUSES.length; i++) {
      if (src[SOLO_BUSES[i][0]]) any = true;
    }
    if (any) {
      for (i = 0; i < buses.length; i++) {
        var soloKey = buses[i] === "dry" ? "solo_dry" : "solo_" + buses[i];
        if (!src[soloKey]) {
          if (buses[i] === "dry") o.dry_gain = 0;
          else o[buses[i] + "_wet"] = 0;
        }
      }
    }
    o.mic_gain_l = stripLinear(src, "l");
    o.mic_gain_c = stripLinear(src, "c");
    o.mic_gain_r = stripLinear(src, "r");
    o.mic_pan_l = src.stereo_mic ? -1 : src.pan_l;
    o.mic_pan_c = src.pan_c;
    o.mic_pan_r = src.stereo_mic ? 1 : src.pan_r;
    o.mic_phase_l = src.phase_l;
    o.mic_phase_c = src.phase_c;
    o.mic_phase_r = src.phase_r;
    return o;
  }

  function liveRequestBody() {
    var o = heardMix(state);
    if (window.LiveFDN) {
      var rate = LiveFDN.rate ? LiveFDN.rate() : 0;
      var rev = LiveFDN.colourRev ? LiveFDN.colourRev() : "";
      if (rate) o.sample_rate = rate;
      if (rev) o.colour_rev = rev;
    }
    return o;
  }

  function paintDecayHint() {
    var el = document.getElementById("decayHint");
    if (!el) return;
    if (state.decay_lock) {
      el.textContent = "Armed. Play live and Render use " +
        Number(state.decay_s).toFixed(2) +
        " s until you move Feedback. Feedback is Structure Gain.";
    } else {
      el.textContent = "Feedback is in charge (" + Number(state.decay_s).toFixed(2) +
        " s). Move Decay to arm a fixed length again.";
    }
  }

  function paintSolos() {
    var any = false;
    var i;
    for (i = 0; i < SOLO_BUSES.length; i++) {
      if (state[SOLO_BUSES[i][0]]) any = true;
    }
    for (i = 0; i < SOLO_BUSES.length; i++) {
      var on = !!state[SOLO_BUSES[i][0]];
      var btn = document.querySelector('.solo-btn[data-solo="' + SOLO_BUSES[i][2] + '"]');
      var row = document.querySelector('.desk-strip[data-mix="' + SOLO_BUSES[i][2] + '"]');
      if (btn) btn.setAttribute("aria-pressed", on ? "true" : "false");
      if (row) row.classList.toggle("is-muted", any && !on);
    }
  }

  var DESK_FADERS = ["l", "c", "r", "direct", "fdn", "early", "dry"];

  function setFader(key, u, fromLink) {
    u = Math.max(0, Math.min(1, Number(u)));
    if (!fromLink) {
      var db = dbFromTravel(u);
      if (isFinite(db) && Math.abs(db) <= 0.25) u = 0.5;
    }
    state["fader_" + key] = u;
    if (fromLink) return;
    if (state.stereo_mic && (key === "l" || key === "r")) {
      setFader(key === "l" ? "r" : "l", u, true);
    }
    if (state.natural_bus && (key === "direct" || key === "fdn")) {
      setFader(key === "direct" ? "fdn" : "direct", u, true);
    }
  }

  function setTrim(key, db, fromLink) {
    db = Math.max(-12, Math.min(12, Number(db)));
    if (!isFinite(db)) db = 0;
    state["trim_" + key] = db;
    if (fromLink) return;
    if (state.natural_bus && (key === "direct" || key === "fdn")) {
      setTrim(key === "direct" ? "fdn" : "direct", db, true);
    }
  }

  function paintDesk() {
    var i, key, fader, trim, pan, read, phase, mute, knob, needle;
    for (i = 0; i < DESK_FADERS.length; i++) {
      key = DESK_FADERS[i];
      fader = document.getElementById("fader_" + key);
      trim = document.getElementById("trim_" + key);
      read = document.getElementById("read_" + key);
      mute = document.getElementById("mute_" + key);
      if (fader) fader.value = state["fader_" + key];
      if (trim) trim.value = state["trim_" + key];
      if (read && !read.querySelector("input")) {
        read.textContent = formatSend(state["fader_" + key], state["trim_" + key]);
      }
      if (mute) mute.setAttribute("aria-pressed", state["mute_" + key] ? "true" : "false");
      var strip = fader && fader.closest(".desk-strip");
      if (strip) strip.classList.toggle("is-silenced", !!state["mute_" + key]);
      if (trim && trim.parentElement) {
        needle = (-140 + ((Number(state["trim_" + key]) + 12) / 24) * 280).toFixed(1) + "deg";
        trim.parentElement.style.setProperty("--needle", needle);
      }
    }
    ["l", "c", "r"].forEach(function (cap) {
      pan = document.getElementById("pan_" + cap);
      phase = document.getElementById("phase_" + cap);
      var locked = state.stereo_mic && cap !== "c";
      if (pan) {
        pan.disabled = locked;
        if (document.activeElement !== pan) {
          pan.value = locked ? (cap === "l" ? -1 : 1) : state["pan_" + cap];
        }
        if (pan.parentElement) {
          var pv = Number(pan.value);
          pan.parentElement.style.setProperty("--needle", (-140 + ((pv + 1) / 2) * 280).toFixed(1) + "deg");
        }
      }
      if (phase) phase.setAttribute("aria-pressed", state["phase_" + cap] < 0 ? "true" : "false");
      var row = document.querySelector('.desk-strip[data-cap="' + cap + '"]');
      if (row) row.classList.toggle("is-linked", !!(state.stereo_mic && cap !== "c"));
      if (row) row.classList.toggle("is-pan-locked", !!locked);
    });
    var stereoBtn = document.getElementById("stereoMicBtn");
    if (stereoBtn) stereoBtn.setAttribute("aria-pressed", state.stereo_mic ? "true" : "false");
    var naturalBtn = document.getElementById("naturalBtn");
    if (naturalBtn) naturalBtn.setAttribute("aria-pressed", state.natural_bus ? "true" : "false");
    ["direct", "fdn"].forEach(function (bus) {
      var row = document.querySelector('.desk-strip[data-mix="' + bus + '"]');
      if (row) row.classList.toggle("is-linked", !!state.natural_bus);
    });
  }

  function bindDesk() {
    DESK_FADERS.forEach(function (key) {
      var fader = document.getElementById("fader_" + key);
      var trim = document.getElementById("trim_" + key);
      var mute = document.getElementById("mute_" + key);
      var read = document.getElementById("read_" + key);
      if (fader) {
        fader.addEventListener("input", function () {
          setFader(key, fader.value, false);
          syncUI();
        });
      }
      if (trim) {
        trim.addEventListener("input", function () {
          setTrim(key, trim.value, false);
          syncUI();
        });
      }
      if (mute) {
        mute.addEventListener("click", function () {
          state["mute_" + key] = !state["mute_" + key];
          syncUI();
        });
      }
      if (read) {
        read.addEventListener("click", function () {
          if (read.querySelector("input")) return;
          var input = document.createElement("input");
          input.type = "number";
          input.step = "0.1";
          input.className = "desk-type";
          var db = dbFromTravel(state["fader_" + key]);
          input.value = isFinite(db) ? String(Math.round((db + Number(state["trim_" + key] || 0)) * 10) / 10) : "";
          read.textContent = "";
          read.appendChild(input);
          input.focus();
          input.select();
          var done = false;
          function commit(cancel) {
            if (done) return;
            done = true;
            if (input.parentNode) input.parentNode.removeChild(input);
            if (!cancel) {
              var raw = String(input.value || "").trim().toLowerCase();
              if (raw === "" || raw === "off" || raw === "-inf" || raw === "-oo") {
                setFader(key, 0, false);
              } else {
                var n = Number(raw);
                if (isFinite(n)) {
                  setFader(key, travelFromDb(n - Number(state["trim_" + key] || 0)), false);
                }
              }
            }
            syncUI();
          }
          input.addEventListener("keydown", function (e) {
            if (e.key === "Enter") { e.preventDefault(); commit(false); }
            else if (e.key === "Escape") commit(true);
          });
          input.addEventListener("blur", function () { commit(false); });
        });
      }
    });
    ["l", "c", "r"].forEach(function (cap) {
      var pan = document.getElementById("pan_" + cap);
      var phase = document.getElementById("phase_" + cap);
      if (pan) {
        pan.addEventListener("input", function () {
          if (state.stereo_mic && cap !== "c") return;
          state["pan_" + cap] = Math.max(-1, Math.min(1, Number(pan.value)));
          syncUI();
        });
      }
      if (phase) {
        phase.addEventListener("click", function () {
          state["phase_" + cap] = state["phase_" + cap] < 0 ? 1 : -1;
          syncUI();
        });
      }
    });
    var stereoBtn = document.getElementById("stereoMicBtn");
    if (stereoBtn) {
      stereoBtn.addEventListener("click", function () {
        state.stereo_mic = !state.stereo_mic;
        if (state.stereo_mic) {
          state.pan_l = -1;
          state.pan_r = 1;
          state.fader_r = state.fader_l;
        }
        syncUI();
      });
    }
    var naturalBtn = document.getElementById("naturalBtn");
    if (naturalBtn) {
      naturalBtn.addEventListener("click", function () {
        state.natural_bus = !state.natural_bus;
        if (state.natural_bus) {
          state.fader_direct = 0.5;
          state.fader_fdn = 0.5;
          state.trim_direct = 0;
          state.trim_fdn = 0;
        }
        syncUI();
      });
    }
  }

  function applyDecayReadout(seconds) {
    state.decay_s = seconds;
    var dEl = document.getElementById("decay_s");
    var dOut = document.getElementById("decay_s_out");
    if (dEl) dEl.value = seconds;
    if (dOut) dOut.textContent = Number(seconds).toFixed(2);
    paintDecayHint();
  }

  function gainFromDecay(decayS, meanMs, n) {
    n = n || 32;
    var meanT = (Number(meanMs) || 80) * 0.001;
    if (decayS <= 0.05 || meanT <= 1e-9) return 0;
    var loop = Math.pow(0.001, meanT / decayS);
    var g = loop / Math.sqrt(n);
    var lim = 0.99 / Math.sqrt(n);
    if (g > lim) g = lim;
    if (g < 0) g = 0;
    return Math.min(1, g * n);
  }

  function scheduleLiveParams() {
    if (!window.LiveFDN || !LiveFDN.isRunning()) return;
    if (liveParamsTimer) clearTimeout(liveParamsTimer);
    liveParamsTimer = setTimeout(pushLiveParams, 45);
  }

  var decayPreviewTimer = null;
  function scheduleDecayPreview() {
    if (window.LiveFDN && LiveFDN.isRunning()) return;
    if (decayPreviewTimer) clearTimeout(decayPreviewTimer);
    if (state.decay_lock) return;
    decayPreviewTimer = setTimeout(pullDecayPreview, 200);
  }

  async function pullDecayPreview() {
    decayPreviewTimer = null;
    if (state.decay_lock || decayFromUser) return;
    if (window.LiveFDN && LiveFDN.isRunning()) return;
    if (liveBusy) {
      scheduleDecayPreview();
      return;
    }
    liveBusy = true;
    try {
      var res = await fetch("/api/live_params", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(state)
      });
      var data = await res.json();
      if (!data.ok) return;
      if (window.LiveFDN && LiveFDN.isRunning()) return;
      if (data.mean_delay_ms) state._mean_delay_ms = data.mean_delay_ms;
      if (!state.decay_lock && !decayFromUser && data.decay_s > 0.05) {
        applyDecayReadout(data.decay_s);
      }
    } catch (err) {
      /* Feedback still drives the render. The number fills in on the next edit. */
    } finally {
      liveBusy = false;
    }
  }

  async function pushLiveParams() {
    if (liveBusy) {
      scheduleLiveParams();
      return;
    }
    liveBusy = true;
    try {
      var res = await fetch("/api/live_params", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(liveRequestBody())
      });
      var data = await res.json();
      if (!data.ok) {
        if (statusEl) statusEl.textContent = data.error || "live_params failed";
        return;
      }
      if (data.mean_delay_ms) state._mean_delay_ms = data.mean_delay_ms;
      if (!state.decay_lock && !decayFromUser && data.decay_s > 0.05) {
        applyDecayReadout(data.decay_s);
      }
      LiveFDN.update(data);
    } catch (err) {
      if (statusEl) statusEl.textContent = String(err);
    } finally {
      liveBusy = false;
    }
  }

  function ensureImageView() {
    if (imageView || imageViewInitFailed) return imageView;
    if (!window.ImageViews) {
      imageViewInitFailed = true;
      if (statusEl) statusEl.textContent = "Images: ImageViews module missing";
      return null;
    }
    var canvas = document.getElementById("imageCanvas");
    if (!canvas) {
      imageViewInitFailed = true;
      if (statusEl) statusEl.textContent = "Images: #imageCanvas missing";
      return null;
    }
    /* Do not create WebGL while layout is still 0×0 (hidden/settling). */
    var rect = canvas.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) return null;
    try {
      imageView = ImageViews.create({ canvas: canvas });
      if (!imageView) {
        imageViewInitFailed = true;
        if (statusEl) statusEl.textContent = "Images: WebGL init failed (Three.js / GPU)";
        return null;
      }
    } catch (err) {
      imageViewInitFailed = true;
      imageView = null;
      if (statusEl) {
        statusEl.textContent = "Images WebGL: " + String(err && err.message ? err.message : err);
      }
      return null;
    }
    return imageView;
  }

  /** After #imageViews is unhidden: double-rAF → init → resize; optional size retry. */
  function paintImageViewsSoon() {
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        if (currentView !== "lattice" && currentView !== "paths") return;
        ensureImageView();
        if (imageView) {
          imageView.resize();
          if (imagesCache) applyImageView();
        }
        var canvas = document.getElementById("imageCanvas");
        if (!canvas) return;
        var rect = canvas.getBoundingClientRect();
        if (rect.width >= 2 && rect.height >= 2) return;
        /* Optional: layout still settling — one short retry */
        setTimeout(function () {
          if (currentView !== "lattice" && currentView !== "paths") return;
          ensureImageView();
          if (imageView) {
            imageView.resize();
            if (imagesCache) applyImageView();
          }
        }, 80);
      });
    });
  }

  var colourSurfacesViews = document.getElementById("colourSurfacesViews");
  var colourSurfaces = null;
  if (window.ColourSurfaces) {
    if (!state.surfaces) state.surfaces = ColourSurfacesDefaults.defaultSurfaces();
    colourSurfaces = new ColourSurfaces({
      getState: function () { return state; },
      onChange: function () { syncUI(); scheduleLiveParams(); }
    });
  }

  var polarView = null;
  var micHero = null;
  var micCatalogue = {};
  if (window.PolarFieldView) {
    polarView = new PolarFieldView({
      getState: function () { return state; },
      onRefresh: function () { schedulePolar(); }
    });
  }


  function fmt(n, d) {
    if (d === undefined) d = 2;
    return Number(n).toFixed(d);
  }

  function selectedMicsFromUI() {
    var boxes = document.querySelectorAll("#micToggles input[data-mic]");
    var out = [];
    boxes.forEach(function (b) {
      if (b.checked) out.push(b.getAttribute("data-mic"));
    });
    if (!out.length) {
      var c = document.querySelector('#micToggles input[data-mic="C"]');
      if (c) { c.checked = true; out = ["C"]; }
    }
    return out;
  }

  function scheduleImagesFetch(delayMs) {
    if (currentView !== "lattice" && currentView !== "paths") return;
    if (imagesFetchTimer) clearTimeout(imagesFetchTimer);
    var ms = delayMs == null ? imagesFetchDelayMs : delayMs;
    imagesFetchTimer = setTimeout(fetchImages, ms);
  }

  async function fetchImages() {
    selectedMics = selectedMicsFromUI();
    var body = Object.assign({}, state, { mics: selectedMics });
    try {
      var res = await fetch("/api/images", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!res.ok) throw new Error("HTTP " + res.status);
      imagesCache = await res.json();
      ensureImageView();
      applyImageView();
      /* Layout may still settle after fetch — resize+apply again next frames */
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          if (currentView !== "lattice" && currentView !== "paths") return;
          if (imageView) {
            imageView.resize();
            applyImageView();
          }
        });
      });
      if (statusEl && (statusEl.textContent.indexOf("Images:") === 0 || statusEl.textContent.indexOf("Images WebGL:") === 0)) {
        statusEl.textContent = "";
      }
    } catch (err) {
      if (statusEl) statusEl.textContent = "Images: " + String(err && err.message ? err.message : err);
    }
  }

  function applyImageView() {
    if (!imagesCache) return;
    if (currentView !== "lattice" && currentView !== "paths") return;
    if (!imageView) ensureImageView();
    if (!imageView) return;
    var mode = currentView === "lattice" ? "lattice" : pathsMode;
    try {
      imageView.setMode(mode);
      imageView.setData(imagesCache);
    } catch (err) {
      if (statusEl) {
        statusEl.textContent = "Images rebuild: " + String(err && err.message ? err.message : err);
      }
      return;
    }
    var n = imagesCache.count || (imagesCache.lattice && imagesCache.lattice.length) || 0;
    var mics = (imagesCache.selected_mics || []).join("+") || "C";
    if (liveMetresImg) {
      var hn = imagesCache.hadamard_n || n;
      liveMetresImg.textContent =
        n + " images · " + hn + " FDN lines · mics " + mics +
        " · c=" + (imagesCache.c || 340) + " m/s" +
        (imagesCache.source_b ? " · two clouds" : "");
    }
  }

  function syncPathsModeUI() {
    document.querySelectorAll(".paths-mode-chip").forEach(function (btn) {
      var on = btn.getAttribute("data-paths-mode") === pathsMode;
      btn.classList.toggle("active", on);
      btn.setAttribute("aria-pressed", on ? "true" : "false");
    });
    if (pathsMode === "legs") {
      if (imageViewTitle) imageViewTitle.textContent = "Last legs into the mic";
      if (imageViewHint) imageViewHint.textContent =
        "Final arrival segment · same Front/Back as Floor · orbit Alt/RMB";
    } else {
      if (imageViewTitle) imageViewTitle.textContent = "In-room specular paths";
      if (imageViewHint) imageViewHint.textContent =
        "Folded bounce paths · same Front/Back as Floor · orbit Alt/RMB";
    }
  }


  var micDesk = null;
  (function () {
    var top = document.getElementById("micFloorCanvas");
    var v3d = document.getElementById("mic3dCanvas");
    if (!top || !window.MicDesk) return;
    micDesk = MicDesk.create({
      topCanvas: top,
      sideCanvas: null,
      view3dCanvas: v3d,
      polarL: document.getElementById("micPolarL"),
      polarC: document.getElementById("micPolarC"),
      polarR: document.getElementById("micPolarR"),
      getState: function () { return state; },
      setState: function (s) { Object.assign(state, s); },
      onChange: syncUI,
      RoomMath: window.RoomMath
    });
  })();



  /* Pattern+yaw IDs live in #capsuleStackListen; on Mic tab relocate under polar plots. */
  function placeCapsuleControls(view) {
    var stack = document.getElementById("capsuleStackListen");
    var yawHint = document.querySelector("#panelListen .yaw-hint");
    var map = { L: "micCapSlotL", C: "micCapSlotC", R: "micCapSlotR" };
    ["L", "C", "R"].forEach(function (cap) {
      var row = document.querySelector('.capsule-row[data-cap="' + cap + '"]');
      if (!row) return;
      var slot = document.getElementById(map[cap]);
      if (view === "mic" && slot) {
        if (row.parentElement !== slot) slot.appendChild(row);
      } else if (stack) {
        if (row.parentElement !== stack) stack.appendChild(row);
      }
    });
    if (stack) stack.hidden = view === "mic";
    if (yawHint) yawHint.hidden = view === "mic";
  }

  /* Sidebar relevance by view — same control may appear on several tabs if useful. */
  function syncSidebar(view) {
    var show = {
      room: true,
      listen: view === "mic" || view === "polar" || view === "lattice" || view === "paths",
      mix: view === "mix" || view === "lattice" || view === "paths" || view === "colour" || view === "surfaces" || view === "polar",
      preview: view !== "mic",
      advanced: true
    };
    var map = {
      room: document.getElementById("panelRoom"),
      listen: document.getElementById("panelListen"),
      mix: document.getElementById("panelMix"),
      preview: document.getElementById("panelPreview"),
      advanced: document.getElementById("panelAdvanced")
    };
    Object.keys(map).forEach(function (key) {
      if (map[key]) map[key].hidden = !show[key];
    });
  }

  function setView(view) {
    currentView = view;

    document.querySelectorAll(".view-tab").forEach(function (tab) {
      var on = tab.getAttribute("data-view") === view;
      tab.classList.toggle("active", on);
      tab.setAttribute("aria-selected", on ? "true" : "false");
    });

    var isEdit = view === "edit";
    var isMic = view === "mic";
    var isImage = view === "lattice" || view === "paths";
    var isCS = view === "colour" || view === "surfaces" || view === "polar";
    if (editViews) editViews.hidden = !isEdit;
    if (micViews) micViews.hidden = !isMic;
    if (mixViews) mixViews.hidden = view !== "mix";
    if (imageViewsEl) imageViewsEl.hidden = !isImage;
    if (colourSurfacesViews) colourSurfacesViews.hidden = !isCS;
    if (micToggles) micToggles.hidden = !isImage;

    /* Per-tab sidebar: only show controls relevant to the current view. */
    syncSidebar(view);
    placeCapsuleControls(view);

    var pathsModeRow = document.getElementById("pathsModeRow");
    if (pathsModeRow) pathsModeRow.hidden = view !== "paths";

    if (view === "lattice") {
      if (imageViewTitle) imageViewTitle.textContent = "Mirrored-room lattice";
      if (imageViewHint) imageViewHint.textContent =
        "Wireframe image rooms · same Front/Back as Floor · orbit Alt/RMB";
    } else if (view === "paths") {
      syncPathsModeUI();
    }

    if (isEdit) {
      editor.redraw();
    } else if (isMic) {
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          if (currentView !== "mic") return;
          if (micDesk) {
            if (micDesk.view3d && micDesk.view3d.resize) micDesk.view3d.resize();
            micDesk.redraw();
          }
          ensureMicHero();
          if (micHero && micHero.resize) micHero.resize();
          schedulePolar();
        });
      });
    } else if (isImage) {
      /* Lazy-init WebGL only after panel is unhidden (avoid 0×0 canvas context). */
      scheduleImagesFetch(80);
      paintImageViewsSoon();
    } else if (isCS && colourSurfaces) {
      colourSurfaces.setMode(view === "polar" ? "colour" : view);
      colourSurfaces.drawColour();
      colourSurfaces.drawSurfaceGraphs();
      if (view === "polar" && polarView) {
        polarView.resize();
        schedulePolar();
      }
    }
  }

  function syncHadamardUI() {
    var n = state.hadamard_n || 32;
    document.querySelectorAll(".hadamard-chip").forEach(function (btn) {
      var bn = parseInt(btn.getAttribute("data-n"), 10);
      btn.classList.toggle("active", bn === n);
    });
    var ro = document.getElementById("hadamardReadout");
    if (ro) ro.textContent = n + " images · " + n + " FDN lines";
  }

  function setHadamardN(n) {
    var allowed = [8, 16, 32, 64, 128];
    if (allowed.indexOf(n) < 0) n = 32;
    state.hadamard_n = n;
    syncHadamardUI();
    if (currentView === "lattice" || currentView === "paths") scheduleImagesFetch(120);
  }

  function setPolarMics(ids) {
    var want = {};
    (ids || []).forEach(function (id) { want[id] = true; });
    document.querySelectorAll("#polarToggles input[data-polar]").forEach(function (box) {
      var id = box.getAttribute("data-polar");
      if (id === "sum") {
        box.checked = !ids || !ids.length;
        return;
      }
      box.checked = !!want[id];
    });
    // If L/C/R selected, uncheck sum; if none, keep sum
    var any = false;
    document.querySelectorAll("#polarToggles input[data-polar]").forEach(function (box) {
      var id = box.getAttribute("data-polar");
      if (id !== "sum" && box.checked) any = true;
    });
    var sumBox = document.querySelector("#polarToggles input[data-polar=\"sum\"]");
    if (sumBox) sumBox.checked = !any;
  }

  function near(a, b, eps) {
    return Math.abs(Number(a) - Number(b)) <= (eps != null ? eps : 0.02);
  }

  function matchPresetId() {
    var ids = Object.keys(MIC_PRESETS);
    for (var i = 0; i < ids.length; i++) {
      var id = ids[i];
      var p = MIC_PRESETS[id];
      if (!p) continue;
      if (!near(state.space, p.space, 0.015)) continue;
      if (!near(state.toe_half_deg, p.toe_half_deg, 0.6)) continue;
      if (p.family_l && state.family_l !== p.family_l) continue;
      if (p.family_c && state.family_c !== p.family_c) continue;
      if (p.family_r && state.family_r !== p.family_r) continue;
      if (p.polar_l != null && !near(state.polar_l, p.polar_l, 0.08)) continue;
      if (p.polar_c != null && !near(state.polar_c, p.polar_c, 0.08)) continue;
      if (p.polar_r != null && !near(state.polar_r, p.polar_r, 0.08)) continue;
      if (p.yaw_l_deg != null && !near(state.yaw_l_deg, p.yaw_l_deg, 0.8)) continue;
      if (p.yaw_c_deg != null && !near(state.yaw_c_deg, p.yaw_c_deg, 0.8)) continue;
      if (p.yaw_r_deg != null && !near(state.yaw_r_deg, p.yaw_r_deg, 0.8)) continue;
      if (!!state.ms_decode !== (id === "ms_classic")) continue;
      return id;
    }
    return "custom";
  }

  function applyMicPreset(id, fromUser) {
    if (id === "custom" || !MIC_PRESETS[id]) {
      state.mic_setup = "custom";
      var sel = document.getElementById("mic_setup");
      if (sel) sel.value = "custom";
      return;
    }
    var p = MIC_PRESETS[id];
    _applyingPreset = true;
    state.mic_setup = id;
    state.space = p.space;
    state.toe_half_deg = p.toe_half_deg;
    state.car_omni = p.car_omni;
    state.diverg = divergFromToe(p.toe_half_deg);
    if (p.pattern_l) state.pattern_l = p.pattern_l;
    if (p.pattern_c) state.pattern_c = p.pattern_c;
    if (p.pattern_r) state.pattern_r = p.pattern_r;
    if (p.family_l) state.family_l = p.family_l;
    if (p.family_c) state.family_c = p.family_c;
    if (p.family_r) state.family_r = p.family_r;
    if (p.polar_l != null) state.polar_l = p.polar_l;
    if (p.polar_c != null) state.polar_c = p.polar_c;
    if (p.polar_r != null) state.polar_r = p.polar_r;
    if (p.yaw_l_deg != null) state.yaw_l_deg = p.yaw_l_deg;
    if (p.yaw_c_deg != null) state.yaw_c_deg = p.yaw_c_deg;
    if (p.yaw_r_deg != null) state.yaw_r_deg = p.yaw_r_deg;
    state.ms_decode = id === "ms_classic";
    state.preset_owns_pattern = false;
    var divergEl = document.getElementById("diverg");
    if (divergEl) divergEl.value = String(state.diverg);
    setPolarMics(p.polar);
    Object.assign(state, RoomMath.clampRoom(state));
    syncUI();
    _applyingPreset = false;
  }

  function markCustomIfDrifted() {
    if (_applyingPreset) return;
    var matched = matchPresetId();
    state.mic_setup = matched;
    var sel = document.getElementById("mic_setup");
    if (sel && sel.value !== matched) sel.value = matched;
  }

  function presetHz(id) {
    var row = micCatalogue[id];
    var hz = row && row.hpf_hz != null ? Number(row.hpf_hz) : null;
    return hz != null && isFinite(hz) && hz > 0 ? hz : null;
  }

  function paintMicModel() {
    var sideSel = document.getElementById("mic_preset_side");
    var centreSel = document.getElementById("mic_preset_centre");
    var mode = document.getElementById("colour_mode");
    var badge = document.getElementById("micHonestyBadge");
    var sideId = state.mic_preset_l || "ShureSM57";
    var centreId = state.mic_preset_c || sideId;
    function setSel(sel, id) {
      if (!sel || document.activeElement === sel) return;
      if (sel.querySelector("option[value='" + id + "']")) sel.value = id;
    }
    setSel(sideSel, sideId);
    setSel(centreSel, centreId);
    if (mode && document.activeElement !== mode) mode.value = state.colour_mode || "MEASURED_SHELF";
    function paintHpf(boxId, rowId, labelId, hintId, hz, flag) {
      var box = document.getElementById(boxId);
      var row = document.getElementById(rowId);
      var label = document.getElementById(labelId);
      var hint = document.getElementById(hintId);
      var can = hz != null;
      if (!can) state[flag] = false;
      if (box) {
        box.disabled = !can;
        box.checked = !!state[flag] && can;
      }
      if (row) row.classList.toggle("is-disabled", !can);
      if (label) label.textContent = can ? ("High-pass " + Math.round(hz) + " Hz") : "No high-pass";
      if (hint) hint.textContent = can ? "Off until engaged." : "This microphone has none.";
    }
    paintHpf("mic_hpf_sides", "micHpfSidesRow", "micHpfSidesLabel", "micHpfSidesHint", presetHz(sideId), "mic_hpf_sides");
    paintHpf("mic_hpf_centre", "micHpfCentreRow", "micHpfCentreLabel", "micHpfCentreHint", presetHz(centreId), "mic_hpf_centre");
    state.mic_hpf_engaged = !!(state.mic_hpf_sides || state.mic_hpf_centre);
    var sideRow = micCatalogue[sideId];
    var centreRow = micCatalogue[centreId];
    var honesty = "MEASURED";
    if ((sideRow && String(sideRow.honesty).toUpperCase() === "ASSUMED")
      || (centreRow && String(centreRow.honesty).toUpperCase() === "ASSUMED")) {
      honesty = "ASSUMED";
    }
    if (badge) {
      badge.textContent = honesty;
      badge.className = "honesty-badge honesty-" + honesty.toLowerCase();
    }
  }

  function applyCapsulePreset(slots, id) {
    var row = micCatalogue[id];
    slots.forEach(function (slot) {
      state["mic_preset_" + slot] = id;
      if (row && row.capsule) {
        state["pattern_" + slot] = row.capsule.pattern;
        state["family_" + slot] = row.capsule.family;
        state["polar_" + slot] = row.capsule.polar;
      }
    });
    if (row && row.capsule) state.preset_owns_pattern = true;
    if (presetHz(state.mic_preset_l) == null) state.mic_hpf_sides = false;
    if (presetHz(state.mic_preset_c) == null) state.mic_hpf_centre = false;
    state.mic_hpf_engaged = !!(state.mic_hpf_sides || state.mic_hpf_centre);
    syncUI();
  }

  function heroEnabled() {
    var same = state.mic_preset_l === state.mic_preset_c
      && state.mic_preset_c === state.mic_preset_r
      && state.pattern_l === state.pattern_c
      && state.pattern_c === state.pattern_r
      && state.family_l === state.family_c
      && state.family_c === state.family_r;
    if (same) return { L: false, C: true, R: false, sum: false };
    return { L: true, C: true, R: true, sum: false };
  }

  function ensureMicHero() {
    if (micHero || !window.PolarFieldView) return micHero;
    var canvas = document.getElementById("micPolarHero");
    if (!canvas) return null;
    micHero = new PolarFieldView({
      canvas: canvas,
      wrap: document.getElementById("micHeroWrap"),
      meta: document.getElementById("micHeroMeta"),
      isolated: true,
      useBase: true,
      enabled: { L: false, C: false, R: false, sum: false, base: true },
      getState: function () { return state; }
    });
    return micHero;
  }

  var polarTimer = null;
  var polarReq = 0;
  function schedulePolar() {
    if (currentView !== "mic" && currentView !== "polar") return;
    if (polarTimer) clearTimeout(polarTimer);
    polarTimer = setTimeout(refreshPolar, 120);
  }
  async function refreshPolar() {
    polarTimer = null;
    var seq = ++polarReq;
    try {
      var body = Object.assign({}, state);
      body.n_az = 72;
      if (body.sy == null && body.my != null) body.sy = body.my;
      var res = await fetch("/api/polar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!res.ok) throw new Error("HTTP " + res.status);
      var data = await res.json();
      if (seq !== polarReq) return;
      if (!data.ok) throw new Error(data.error || "polar failed");
      if (micDesk && micDesk.setPolar) micDesk.setPolar(data);
      ensureMicHero();
      if (micHero) {
        micHero.enabled = { L: false, C: false, R: false, sum: false, base: true };
        micHero.setData(data);
      }
      if (polarView && polarView.setData) polarView.setData(data);
      var banner = document.getElementById("polarBanner");
      if (banner && data.assumed_note) banner.textContent = data.assumed_note;
    } catch (err) {
      var meta = document.getElementById("micHeroMeta");
      if (meta) meta.textContent = "Polar: " + String(err);
    }
  }

  function loadMicCatalogue() {
    fetch("/api/mic_presets").then(function (res) {
      if (!res.ok) throw new Error("HTTP " + res.status);
      return res.json();
    }).then(function (data) {
      var groups = { MEASURED: [], ASSUMED: [] };
      micCatalogue = {};
      (data.presets || []).forEach(function (row) {
        if (!row || !row.mic_id) return;
        micCatalogue[row.mic_id] = row;
        var key = String(row.honesty || "").toUpperCase() === "MEASURED" ? "MEASURED" : "ASSUMED";
        groups[key].push(row);
      });
      function fill(sel, id) {
        if (!sel) return;
        sel.innerHTML = "";
        [["MEASURED", "Measured"], ["ASSUMED", "Assumed"]].forEach(function (pair) {
          if (!groups[pair[0]].length) return;
          var og = document.createElement("optgroup");
          og.label = pair[1];
          groups[pair[0]].forEach(function (row) {
            var opt = document.createElement("option");
            opt.value = row.mic_id;
            opt.textContent = row.display_name || row.mic_id;
            og.appendChild(opt);
          });
          sel.appendChild(og);
        });
        if (id && micCatalogue[id]) sel.value = id;
      }
      fill(document.getElementById("mic_preset_side"), state.mic_preset_l || "ShureSM57");
      fill(document.getElementById("mic_preset_centre"), state.mic_preset_c || "ShureSM57");
      paintMicModel();
    }).catch(function () {});
  }

  function syncUI() {
    if (syncRaf) return;
    syncRaf = requestAnimationFrame(function () {
      syncRaf = 0;
      syncUINow();
    });
  }

  function balanceLabel(v) {
    v = Number(v) || 0;
    if (Math.abs(v) < 0.001) return "Centre";
    if (v <= -0.995) return "A";
    if (v >= 0.995) return "B";
    return (v > 0 ? "+" : "") + v.toFixed(2);
  }

  function paintSourceSplit() {
    var oneBtn = document.getElementById("oneSourceBtn");
    var twoBtn = document.getElementById("twoSourceBtn");
    var extra = document.getElementById("twoSourceExtra");
    var can = wavChannels >= 2;
    if (oneBtn) {
      oneBtn.classList.toggle("active", !state.two_sources);
      oneBtn.setAttribute("aria-pressed", state.two_sources ? "false" : "true");
    }
    if (twoBtn) {
      twoBtn.disabled = !can;
      twoBtn.classList.toggle("active", !!state.two_sources && can);
      twoBtn.setAttribute("aria-pressed", state.two_sources && can ? "true" : "false");
    }
    if (extra) extra.hidden = !state.two_sources;
    var mir = document.getElementById("mirrorB");
    if (mir) mir.checked = !!state.mirror_b;
    var bal = document.getElementById("sourceBalance");
    var balOut = document.getElementById("sourceBalanceOut");
    if (bal && document.activeElement !== bal) bal.value = String(state.source_balance || 0);
    if (balOut) balOut.textContent = balanceLabel(state.source_balance || 0);
  }

  function wavChannelCount(file) {
    return file.slice(0, 128).arrayBuffer().then(function (ab) {
      var u = new Uint8Array(ab);
      if (u.length < 24) return 1;
      if (u[0] !== 82 || u[1] !== 73 || u[2] !== 70 || u[3] !== 70) return 1;
      if (u[12] === 102 && u[13] === 109 && u[14] === 116 && u[15] === 32) {
        return u[22] | (u[23] << 8);
      }
      var i = 12;
      while (i + 8 <= u.length) {
        var id = String.fromCharCode(u[i], u[i + 1], u[i + 2], u[i + 3]);
        var sz = u[i + 4] | (u[i + 5] << 8) | (u[i + 6] << 16) | (u[i + 7] << 24);
        if (id === "fmt ") {
          var chOff = i + 10;
          if (chOff + 1 < u.length) return u[chOff] | (u[chOff + 1] << 8);
        }
        if (sz <= 0 || i + 8 + sz > u.length) break;
        i += 8 + sz + (sz & 1);
      }
      return 1;
    });
  }

  function syncUINow() {
    if (wavChannels < 2) state.two_sources = false;
    var geo = RoomMath.compute(state);
    Object.assign(state, geo.state);
    var spaceEl = document.getElementById("space");
    if (spaceEl) spaceEl.max = Math.max(0.01, geo.max_space);

    var numeric = ["W","H","L","space","car_omni","fdn_g","ir_length_ms","humidity","air_lp","air_shelf","decay_s"];
    for (var i = 0; i < numeric.length; i++) {
      var id = numeric[i];
      var el = document.getElementById(id);
      var out = document.getElementById(id + "_out");
      if (!el || !out) continue;
      el.value = state[id];
      if (id === "car_omni") {
        var v = state[id];
        out.textContent = v >= 0.66 ? "Cardioid" : (v <= 0.33 ? "Omni" : "Blend");
      } else if (id === "ir_length_ms") {
        out.textContent = String(Math.round(state[id]));
      } else {
        out.textContent = fmt(state[id], (id === "W" || id === "H" || id === "L") ? 1 : 2);
      }
    }
    var toeEl = document.getElementById("toe_half_deg");
    var toeOut = document.getElementById("toe_half_deg_out");
    if (toeEl && state.toe_half_deg != null) {
      toeEl.value = state.toe_half_deg;
      if (toeOut) toeOut.textContent = "±" + fmt(state.toe_half_deg, 1) + "°";
    }
    var divergEl = document.getElementById("diverg");
    if (divergEl) divergEl.value = state.diverg != null ? state.diverg : 1;
    if (!_applyingPreset) markCustomIfDrifted();
    var setupEl = document.getElementById("mic_setup");
    if (setupEl && state.mic_setup && document.activeElement !== setupEl) {
      setupEl.value = state.mic_setup;
    }
    var parity = document.getElementById("reaktor_parity");
    if (parity) parity.checked = !!state.reaktor_parity;
    var liveDrag = document.getElementById("live_drag_render");
    if (liveDrag) liveDrag.checked = !!state.live_drag_render;
    syncHadamardUI();
    var seedEl = document.getElementById("diffusion_seed");
    var seedMix = document.getElementById("diffusion_seed_mix");
    if (seedEl) seedEl.value = String(state.diffusion_seed != null ? state.diffusion_seed : 0);
    if (seedMix) seedMix.value = String(state.diffusion_seed != null ? state.diffusion_seed : 0);
    var lamEl = document.getElementById("lambda_ref");
    if (lamEl) lamEl.value = String(state.lambda_ref != null ? state.lambda_ref : 0.02);
    var linkEl = document.getElementById("link_heights");
    if (linkEl) linkEl.checked = !!state.link_heights;
    var linkElMic = document.getElementById("link_heights_mic");
    if (linkElMic) linkElMic.checked = !!state.link_heights;
    var readout =
      (geo.source_b ? "A " : "Src ") + fmt(state.sx) + "," + fmt(state.sz) +
      " @ " + fmt(state.sy != null ? state.sy : state.my) + " m  ·  Mic " +
      fmt(state.mcx) + "," + fmt(state.mcz) +
      " @ " + fmt(state.my) + " m  ·  |S−C| " + fmt(geo.distances.sc) + " m";
    if (geo.source_b) {
      readout += "  ·  B " + fmt(geo.source_b.x) + "," + fmt(geo.source_b.z) +
        " @ " + fmt(geo.source_b.y) + " m";
    }
    if (liveMetres) liveMetres.textContent = readout;
    if (liveMetres3d) liveMetres3d.textContent = readout;

    (function () {
      function setM(id, val, digits) {
        var el = document.getElementById(id);
        var out = document.getElementById(id + "_out");
        if (el) el.value = val;
        if (out) {
          if (digits == null) digits = 2;
          out.textContent = Number(val).toFixed(digits);
        }
      }
      setM("mcx", state.mcx);
      setM("mcz", state.mcz);
      setM("my", state.my);
      setM("sy", state.sy != null ? state.sy : state.my);
      ["l", "c", "r"].forEach(function (cap) {
        var fam = document.getElementById("family_" + cap);
        var pol = document.getElementById("polar_" + cap);
        var polOut = document.getElementById("polar_" + cap + "_out");
        var keyF = "family_" + cap;
        var keyP = "polar_" + cap;
        if (fam && state[keyF]) fam.value = state[keyF];
        if (pol && state[keyP] != null) pol.value = state[keyP];
        if (polOut) {
          polOut.textContent = (window.RoomMath && RoomMath.polarLabel)
            ? RoomMath.polarLabel(state[keyF], state[keyP])
            : Number(state[keyP] || 0).toFixed(2);
        }
        var lockPattern = (state.colour_mode || "MEASURED_SHELF") === "MEASURED_SHELF";
        if (fam) fam.disabled = lockPattern;
        if (pol) pol.disabled = lockPattern || state[keyF] === "bi";
        if (window.RoomMath && RoomMath.derivePattern) {
          state["pattern_" + cap] = RoomMath.derivePattern(state[keyF], state[keyP]);
        }
      });
      var ah = document.getElementById("align_horizontal");
      if (ah) ah.checked = !!state.align_horizontal;
      var lr = document.getElementById("link_lr_yaw");
      if (lr) lr.checked = state.link_lr_yaw !== false;
      var hpOn = document.getElementById("mic_hp_on");
      if (hpOn) hpOn.checked = !!state.mic_hp_on;
      setM("mic_hp_hz", state.mic_hp_hz, 0);
      setM("mic_response_hz", state.mic_response_hz, 0);
      setM("mic_proximity", state.mic_proximity, 2);
      setM("capsule_mm", state.capsule_mm != null ? state.capsule_mm : 17, 1);
      if (typeof liveMetresMic !== "undefined" && liveMetresMic) {
        liveMetresMic.textContent =
          "space " + fmt(state.space) + " m · C " +
          ((state.centre_dz || 0) * 100).toFixed(0) + " cm · " +
          fmt(state.my) + " m high";
      }
      if (micDesk) micDesk.redraw();
    })();

    paintSourceSplit();
    editor.redraw();
    if (currentView === "lattice" || currentView === "paths") scheduleImagesFetch();
    paintMicModel();
    paintSolos();
    paintDesk();
    paintDecayHint();
    scheduleLiveParams();
    scheduleDecayPreview();
    schedulePolar();
  }

  function onRoomDim(key, val) {
    // Absolute metres stay put when room size changes (clamp only).
    state[key] = val;
    Object.assign(state, RoomMath.clampRoom(state));
    syncUI();
  }

  ["W","H","L"].forEach(function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("input", function (e) {
      onRoomDim(id, parseFloat(e.target.value));
    });
  });
  ["space","car_omni","fdn_g","ir_length_ms","humidity","air_lp","air_shelf"].forEach(function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("input", function (e) {
      state[id] = parseFloat(e.target.value);
      Object.assign(state, RoomMath.clampRoom(state));
      if (id === "space" || id === "car_omni") markCustomIfDrifted();
      if (id === "fdn_g") { decayFromUser = false; state.decay_lock = false; }
      syncUI();
    });
  });
  var decayEl = document.getElementById("decay_s");
  if (decayEl) {
    decayEl.addEventListener("input", function (e) {
      decayFromUser = true;
      state.decay_lock = true;
      state.decay_s = parseFloat(e.target.value);
      Object.assign(state, RoomMath.clampRoom(state));
      syncUI();
    });
  }
  document.querySelectorAll(".solo-btn").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var bus = btn.getAttribute("data-solo");
      var i;
      for (i = 0; i < SOLO_BUSES.length; i++) {
        if (SOLO_BUSES[i][2] === bus) state[SOLO_BUSES[i][0]] = !state[SOLO_BUSES[i][0]];
      }
      syncUI();
    });
  });
  var toeSlider = document.getElementById("toe_half_deg");
  if (toeSlider) {
    toeSlider.addEventListener("input", function (e) {
      state.toe_half_deg = parseFloat(e.target.value);
      state.diverg = divergFromToe(state.toe_half_deg);
      var divergEl = document.getElementById("diverg");
      if (divergEl) divergEl.value = String(state.diverg);
      Object.assign(state, RoomMath.clampRoom(state));
      markCustomIfDrifted();
      syncUI();
    });
  }
  var micSetupEl = document.getElementById("mic_setup");
  if (micSetupEl) {
    micSetupEl.addEventListener("change", function (e) {
      applyMicPreset(e.target.value, true);
    });
  }
  var parityEl = document.getElementById("reaktor_parity");
  if (parityEl) {
    parityEl.addEventListener("change", function (e) {
      state.reaktor_parity = e.target.checked;
      Object.assign(state, RoomMath.clampRoom(state));
      syncUI();
    });
  }

  function bindSeed(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("input", function (e) {
      var v = parseInt(e.target.value, 10);
      if (!isFinite(v)) v = 0;
      state.diffusion_seed = v;
      var a = document.getElementById("diffusion_seed");
      var b = document.getElementById("diffusion_seed_mix");
      if (a && a !== e.target) a.value = String(v);
      if (b && b !== e.target) b.value = String(v);
    });
  }
  bindSeed("diffusion_seed");
  bindSeed("diffusion_seed_mix");
  var lamEl = document.getElementById("lambda_ref");
  if (lamEl) {
    lamEl.addEventListener("input", function (e) {
      var v = parseFloat(e.target.value);
      if (!isFinite(v)) v = 0.02;
      state.lambda_ref = Math.max(0, Math.min(1, v));
    });
  }

  function bindLinkHeights(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("change", function (e) {
      state.link_heights = !!e.target.checked;
      var a = document.getElementById("link_heights");
      var b = document.getElementById("link_heights_mic");
      if (a && a !== e.target) a.checked = state.link_heights;
      if (b && b !== e.target) b.checked = state.link_heights;
      syncUI();
    });
  }
  bindLinkHeights("link_heights");
  bindLinkHeights("link_heights_mic");

  ["mcx", "mcz", "my", "sy"].forEach(function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("input", function (e) {
      var v = parseFloat(e.target.value);
      if (!isFinite(v)) return;
      state[id] = v;
      if (id === "my") {
        state.my_l = v;
        state.my_c = v;
        state.my_r = v;
      }
      if (id === "my" && state.link_heights) state.sy = v;
      if (id === "sy" && state.link_heights) state.my = v;
      if (window.RoomMath && RoomMath.clampRoom) Object.assign(state, RoomMath.clampRoom(state));
      syncUI();
    });
  });

  ["l", "c", "r"].forEach(function (cap) {
    var fam = document.getElementById("family_" + cap);
    var pol = document.getElementById("polar_" + cap);
    function pushPattern() {
      if (window.RoomMath && RoomMath.derivePattern) {
        state["pattern_" + cap] = RoomMath.derivePattern(state["family_" + cap], state["polar_" + cap]);
      }
      state.preset_owns_pattern = false;
      markCustomIfDrifted();
      syncUI();
    }
    if (fam) {
      fam.addEventListener("change", function (e) {
        state["family_" + cap] = e.target.value;
        pushPattern();
      });
    }
    if (pol) {
      pol.addEventListener("input", function (e) {
        var v = parseFloat(e.target.value);
        if (!isFinite(v)) return;
        state["polar_" + cap] = v;
        if (state.link_lr_yaw && (cap === "l" || cap === "r")) {
          var other = cap === "l" ? "r" : "l";
          state["polar_" + other] = v;
          state["family_" + other] = state["family_" + cap];
        }
        pushPattern();
      });
    }
  });
  function bindCheck(id, key) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("change", function (e) {
      state[key] = !!e.target.checked;
      if (key === "align_horizontal" && state.align_horizontal) {
        state.centre_dz = 0;
        var yPair = state.my_l != null ? state.my_l : state.my;
        state.my_l = yPair;
        state.my_r = yPair;
      }
      Object.assign(state, RoomMath.clampRoom(state));
      syncUI();
    });
  }
  bindCheck("align_horizontal", "align_horizontal");
  bindCheck("link_lr_yaw", "link_lr_yaw");
  bindCheck("mic_hp_on", "mic_hp_on");
  var sidePreset = document.getElementById("mic_preset_side");
  if (sidePreset) {
    sidePreset.addEventListener("change", function (e) {
      applyCapsulePreset(["l", "r"], e.target.value);
    });
  }
  var centrePreset = document.getElementById("mic_preset_centre");
  if (centrePreset) {
    centrePreset.addEventListener("change", function (e) {
      applyCapsulePreset(["c"], e.target.value);
    });
  }
  function refitDiagrams() {
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        if (micDesk && micDesk.redraw) micDesk.redraw();
        if (micDesk && micDesk.view3d && micDesk.view3d.resize) micDesk.view3d.resize();
        if (micHero && micHero.resize) micHero.resize();
        if (polarView && polarView.resize) polarView.resize();
      });
    });
  }
  document.querySelectorAll(".diagram-expand").forEach(function (btn) {
    btn.addEventListener("click", function (evt) {
      evt.preventDefault();
      evt.stopPropagation();
      var frame = btn.closest(".diagram-frame");
      if (!frame) return;
      var open = document.querySelector(".diagram-frame.is-enlarged");
      if (open && open !== frame) {
        open.classList.remove("is-enlarged");
        var other = open.querySelector(".diagram-expand");
        if (other) {
          other.textContent = "Enlarge";
          other.setAttribute("aria-pressed", "false");
        }
      }
      var on = frame.classList.toggle("is-enlarged");
      btn.textContent = on ? "Close" : "Enlarge";
      btn.setAttribute("aria-pressed", on ? "true" : "false");
      refitDiagrams();
    });
  });
  document.addEventListener("keydown", function (evt) {
    if (evt.key !== "Escape") return;
    var open = document.querySelector(".diagram-frame.is-enlarged");
    if (!open) return;
    open.classList.remove("is-enlarged");
    var btn = open.querySelector(".diagram-expand");
    if (btn) {
      btn.textContent = "Enlarge";
      btn.setAttribute("aria-pressed", "false");
    }
    refitDiagrams();
  });
  var modeSel = document.getElementById("colour_mode");
  if (modeSel) {
    modeSel.addEventListener("change", function (e) {
      state.colour_mode = e.target.value || "MEASURED_SHELF";
      syncUI();
    });
  }
  function bindHpf(id, flag) {
    var box = document.getElementById(id);
    if (!box) return;
    box.addEventListener("change", function (e) {
      if (e.target.disabled) {
        state[flag] = false;
        e.target.checked = false;
        return;
      }
      state[flag] = !!e.target.checked;
      state.mic_hpf_engaged = !!(state.mic_hpf_sides || state.mic_hpf_centre);
      syncUI();
    });
  }
  bindHpf("mic_hpf_sides", "mic_hpf_sides");
  bindHpf("mic_hpf_centre", "mic_hpf_centre");
  ["mic_hp_hz", "mic_response_hz", "mic_proximity", "capsule_mm"].forEach(function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("input", function (e) {
      var v = parseFloat(e.target.value);
      if (!isFinite(v)) return;
      state[id] = v;
      syncUI();
    });
  });

  document.querySelectorAll(".paths-mode-chip").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var m = btn.getAttribute("data-paths-mode");
      pathsMode = (m === "legs") ? "legs" : "paths";
      syncPathsModeUI();
      if (currentView === "paths") {
        if (imagesCache) applyImageView();
        else scheduleImagesFetch(80);
      }
    });
  });

  document.querySelectorAll(".view-tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      setView(tab.getAttribute("data-view"));
    });
  });

  document.querySelectorAll("#micToggles input[data-mic]").forEach(function (box) {
    box.addEventListener("change", function () {
      selectedMics = selectedMicsFromUI();
      scheduleImagesFetch(120);
    });
  });
  var micAll = document.getElementById("micAll");
  if (micAll) {
    micAll.addEventListener("click", function () {
      document.querySelectorAll("#micToggles input[data-mic]").forEach(function (b) {
        b.checked = true;
      });
      selectedMics = ["L", "C", "R"];
      scheduleImagesFetch(120);
    });
  }


  document.querySelectorAll(".hadamard-chip").forEach(function (btn) {
    btn.addEventListener("click", function () {
      setHadamardN(parseInt(btn.getAttribute("data-n"), 10));
    });
  });

  var wavInput = document.getElementById("wavInput");
  if (wavInput) {
    wavInput.addEventListener("change", function (e) {
      wavFile = (e.target.files && e.target.files[0]) || null;
      wavChannels = 0;
      if (fileName) fileName.textContent = wavFile ? wavFile.name : "No file loaded";
      if (!wavFile) {
        state.two_sources = false;
        syncUI();
        return;
      }
      wavChannelCount(wavFile).then(function (nch) {
        if (wavFile !== (e.target.files && e.target.files[0])) return;
        wavChannels = nch >= 2 ? nch : 1;
        if (wavChannels < 2) state.two_sources = false;
        syncUI();
      }).catch(function () {
        wavChannels = 1;
        state.two_sources = false;
        syncUI();
      });
    });
  }
  var oneSourceBtn = document.getElementById("oneSourceBtn");
  var twoSourceBtn = document.getElementById("twoSourceBtn");
  if (oneSourceBtn) {
    oneSourceBtn.addEventListener("click", function () {
      state.two_sources = false;
      syncUI();
    });
  }
  if (twoSourceBtn) {
    twoSourceBtn.addEventListener("click", function () {
      if (wavChannels < 2) return;
      state.two_sources = true;
      Object.assign(state, RoomMath.clampRoom(state));
      syncUI();
    });
  }
  var mirrorB = document.getElementById("mirrorB");
  if (mirrorB) {
    mirrorB.addEventListener("change", function (e) {
      state.mirror_b = !!e.target.checked;
      Object.assign(state, RoomMath.clampRoom(state));
      syncUI();
    });
  }
  var sourceBalance = document.getElementById("sourceBalance");
  if (sourceBalance) {
    sourceBalance.addEventListener("input", function (e) {
      var v = parseFloat(e.target.value);
      if (!isFinite(v)) v = 0;
      if (Math.abs(v) < 0.04) v = 0;
      state.source_balance = Math.max(-1, Math.min(1, v));
      e.target.value = String(state.source_balance);
      var balOut = document.getElementById("sourceBalanceOut");
      if (balOut) balOut.textContent = balanceLabel(state.source_balance);
      scheduleLiveParams();
    });
  }

  async function doRender() {
    if (!wavFile) {
      if (statusEl) statusEl.textContent = "Load an input WAV first.";
      return;
    }
    if (renderBusy) {
      renderQueued = true;
      return;
    }
    renderBusy = true;
    if (renderBtn) renderBtn.disabled = true;
    if (statusEl) statusEl.textContent = "Rendering…";
    var fd = new FormData();
    fd.append("file", wavFile, wavFile.name);
    fd.append("params_json", JSON.stringify(heardMix(state)));
    try {
      var res = await fetch("/api/render", { method: "POST", body: fd });
      var raw = await res.text();
      var data;
      try {
        data = JSON.parse(raw);
      } catch (parseErr) {
        if (statusEl) {
          statusEl.textContent = "Render server error (HTTP " + res.status + "): " +
            raw.replace(/\s+/g, " ").slice(0, 240);
        }
        return;
      }
      if (!data.ok) {
        if (statusEl) statusEl.textContent = data.error || ("Render failed (HTTP " + res.status + ")");
        return;
      }
      if (statusEl) statusEl.textContent = data.status || "Done";
      if (outPathEl) outPathEl.textContent = data.out_path || "";
      if (previewAudio) {
        previewAudio.src = (data.preview_url || "") + "&t=" + Date.now();
        previewAudio.play().catch(function () {});
      }
      if (data.geometry && data.geometry.params) {
        Object.assign(state, data.geometry.params);
        syncUI();
      }
      if (data.colour && colourSurfaces) {
        colourSurfaces.setColour(data.colour);
        if (currentView !== "colour" && currentView !== "surfaces") {
          setView("colour");
        } else {
          colourSurfaces.drawColour();
        }
      }
      if (currentView === "polar" || currentView === "mic") schedulePolar();
    } catch (err) {
      if (statusEl) statusEl.textContent = String(err);
    } finally {
      renderBusy = false;
      if (renderBtn) renderBtn.disabled = false;
      if (renderQueued) {
        renderQueued = false;
        doRender();
      }
    }
  }

  if (renderBtn) {
    renderBtn.addEventListener("click", function () { doRender(); });
  }
  var snapBtn = document.getElementById("reaktorSnapshotBtn");
  if (snapBtn) {
    snapBtn.addEventListener("click", function () { applyReaktorSnapshot(); });
  }
  bindCheck("live_drag_render", "live_drag_render");

  var PLACES = {
    studio: {
      W: 5.6, H: 2.8, L: 7.2,
      sx: 2.8, sz: 4.6, sy: 1.2, my: 1.2, mcx: 2.8, mcz: 1.55,
      space: 0.17, reaktor_parity: false, humidity: 0.35, fdn_g: 0.85
    },
    club: {
      W: 14, H: 5.2, L: 22,
      sx: 7, sz: 14.5, sy: 1.6, my: 1.6, mcx: 7, mcz: 3.4,
      space: 0.25, reaktor_parity: false, humidity: 0.4, fdn_g: 0.9
    }
  };

  function applyPlace(name) {
    if (name === "hall") {
      applyReaktorSnapshot();
      return;
    }
    var p = PLACES[name];
    if (!p) return;
    Object.keys(p).forEach(function (k) { state[k] = p[k]; });
    Object.assign(state, RoomMath.clampRoom(state));
    syncHadamardUI();
    syncUI();
    if (statusEl) statusEl.textContent = name.charAt(0).toUpperCase() + name.slice(1) + " loaded. Play live or Render.";
  }

  document.querySelectorAll("#placeRow [data-place]").forEach(function (btn) {
    btn.addEventListener("click", function () { applyPlace(btn.getAttribute("data-place")); });
  });

  var liveBtn = document.getElementById("liveBtn");
  if (liveBtn) {
    liveBtn.addEventListener("click", async function () {
      if (window.LiveFDN && LiveFDN.isRunning()) {
        LiveFDN.stop();
        liveBtn.classList.remove("live-on");
        liveBtn.textContent = "Play live";
        if (statusEl) statusEl.textContent = "Live FDN stopped.";
        return;
      }
      if (!wavFile) {
        if (statusEl) statusEl.textContent = "Load a WAV, then Play live.";
        return;
      }
      liveBtn.disabled = true;
      if (statusEl) statusEl.textContent = "Starting live FDN…";
      try {
        if (window.LiveFDN && LiveFDN.prepare) await LiveFDN.prepare();
        var res = await fetch("/api/live_params", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(liveRequestBody())
        });
        var data = await res.json();
        if (!data.ok) {
          if (statusEl) statusEl.textContent = data.error || "live_params failed";
          return;
        }
        if (data.mean_delay_ms) state._mean_delay_ms = data.mean_delay_ms;
        if (previewAudio) {
          try { previewAudio.pause(); } catch (e) {}
        }
        var ok = await LiveFDN.start(wavFile, data);
        if (ok) {
          liveBtn.classList.add("live-on");
          liveBtn.textContent = "Stop live";
        }
      } catch (err) {
        if (statusEl) statusEl.textContent = String(err);
      } finally {
        liveBtn.disabled = false;
      }
    });
  }

  // Default Mic setup = ORTF ±55°. Colour preset is SM57 and does not move yaw.
  bindDesk();
  applyMicPreset(state.mic_setup || "ortf", false);
  loadMicCatalogue();
  setView("edit");
})();
