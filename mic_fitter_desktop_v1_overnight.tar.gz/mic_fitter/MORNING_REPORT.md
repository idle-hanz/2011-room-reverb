# MORNING_REPORT — mic_fitter overnight

**Generated:** 2026-09-22 23:09 BST (Europe/London)
**Runtime:** 16.4 s
**Deadline target:** ready by 08:00 Europe/London

## Executive summary

- Fitted **6** microphones end-to-end (tiny 6-parameter shelf+LP model).
- Deliverables: `presets/`, `plots/polars/`, `plots/colour/`, `plots/fit/`, `reports/`, `logs/fit_run.log`.
- **Room Reverb mix / worklet / default engine path: NOT modified.**
- Structure LP remains a separate room-engine control.

## Data sources (what was actually used)

> MEASURED from Franco et al. Zenodo extract (6 mics, DOI 10.5281/zenodo.4633508). WAVs under /workspace/mic_fitter/data/zenodo. Angles held out: 45°, 135°.

| mic_id | display name | type / family | source | honesty |
|--------|--------------|---------------|--------|---------|
| `ShureSM57` | Shure SM57 — dynamic cardioid | dynamic_cardioid | Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles) | **MEASURED** |
| `SchoepsCMC5UCardioid` | Schoeps CMC5-U Cardioid — SDC | sdc_cardioid | Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles) | **MEASURED** |
| `NeumannU87AiCardioid` | Neumann U87 Ai Cardioid — LDC | ldc_cardioid | Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles) | **MEASURED** |
| `RoyerR121` | Royer R-121 — fig-8 ribbon | fig8_ribbon | Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles) | **MEASURED** |
| `ElectroVoiceRE20` | Electro-Voice RE20 — dynamic cardioid | dynamic_cardioid | Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles) | **MEASURED** |
| `AKGC414Cardioid` | AKG C414 Cardioid — LDC multipattern | ldc_cardioid | Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles) | **MEASURED** |

### Zenodo note

- Preferred dataset: Franco et al. — [Zenodo 4633508](https://zenodo.org/records/4633508) (`Microphone_Impulse_Responses.zip`, ~1.5 GB, 25 mics, 5° steps).
- Overnight: **full zip downloaded** (~1.42 GB) to `data/zenodo/Microphone_Impulse_Responses.zip`; selected Raw_IRs (6 mics × 10 angles, 5 m, 24-bit) extracted to `data/zenodo/extracted/`. Pipeline auto-detects WAVs and tags **MEASURED**.
- Proxy curves mimic published off-axis shapes (omni LF → directional HF shelf + mild LP).

## Mic gallery (visual index)

| Mic | Polar (250/1k/4k/8k) | Colour curves | Preset | Hold-out RMSE |
|-----|----------------------|---------------|--------|---------------|
| **Shure SM57 — dynamic cardioid**<br>`ShureSM57` | [polar PNG](plots/polars/ShureSM57_polar.png) | [colour PNG](plots/colour/ShureSM57_colour.png) | [`ShureSM57.json`](presets/ShureSM57.json) | **5.120 dB** |
| **Schoeps CMC5-U Cardioid — SDC**<br>`SchoepsCMC5UCardioid` | [polar PNG](plots/polars/SchoepsCMC5UCardioid_polar.png) | [colour PNG](plots/colour/SchoepsCMC5UCardioid_colour.png) | [`SchoepsCMC5UCardioid.json`](presets/SchoepsCMC5UCardioid.json) | **5.326 dB** |
| **Neumann U87 Ai Cardioid — LDC**<br>`NeumannU87AiCardioid` | [polar PNG](plots/polars/NeumannU87AiCardioid_polar.png) | [colour PNG](plots/colour/NeumannU87AiCardioid_colour.png) | [`NeumannU87AiCardioid.json`](presets/NeumannU87AiCardioid.json) | **4.515 dB** |
| **Royer R-121 — fig-8 ribbon**<br>`RoyerR121` | [polar PNG](plots/polars/RoyerR121_polar.png) | [colour PNG](plots/colour/RoyerR121_colour.png) | [`RoyerR121.json`](presets/RoyerR121.json) | **3.649 dB** |
| **Electro-Voice RE20 — dynamic cardioid**<br>`ElectroVoiceRE20` | [polar PNG](plots/polars/ElectroVoiceRE20_polar.png) | [colour PNG](plots/colour/ElectroVoiceRE20_colour.png) | [`ElectroVoiceRE20.json`](presets/ElectroVoiceRE20.json) | **4.476 dB** |
| **AKG C414 Cardioid — LDC multipattern**<br>`AKGC414Cardioid` | [polar PNG](plots/polars/AKGC414Cardioid_polar.png) | [colour PNG](plots/colour/AKGC414Cardioid_colour.png) | [`AKGC414Cardioid.json`](presets/AKGC414Cardioid.json) | **4.989 dB** |

Open `reports/gallery.html` in a browser for an inline visual gallery.

## Method

### Model (6 free scalars — anti-overfit by design)

Relative magnitude `H(θ)/H(0°)` in dB on log freqs ~200 Hz–16 kHz:

1. High-shelf: `f0`, `depth_max_db`
2. Soft one-pole: `res_hz`, `lp_mix`, `fc_floor`
3. Angle law: `½(1 − cos θ)^p` with free `p`

On-axis is identically 0 dB. No deep learning. No per-frequency free EQ.

### Loss & anti-overfit choices

- **Primary loss:** mean squared error in dB of relative response.
- **Hold-out angles:** 45° and 135° (never used in training loss).
- **Smoothness penalty:** quadratic pull toward mid-bounds on all 6 params (discourages corner solutions).
- **Hard bounds** on every parameter (see `mic_fitter/model.py` `PARAM_BOUNDS`).
- **Tiny capacity:** 6 scalars cannot memorise lobing notches — intentional.
- Optimiser: `differential_evolution` (global) → `least_squares` TRF polish.

## Hold-out errors & fitted params

### `ShureSM57` — Shure SM57 — dynamic cardioid

- Honesty: **MEASURED** · Family: `dynamic_cardioid`
- Source: `Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles)`
- Train RMSE: **5.349 dB** (MSE 28.612)
- Hold-out RMSE: **5.120 dB** (MSE 26.213)
- Hold-out angles: [45.0, 135.0]
- Train angles: [0.0, 15.0, 30.0, 60.0, 90.0, 120.0, 150.0, 180.0]
- Fit log: `DE success=False nit=100 fun=28.447587; LS success=True cost=7325.037761`
- Params:

```json
{
  "f0": 800.0000000000002,
  "depth_max_db": -23.999999999999996,
  "res_hz": 1856.3954269891963,
  "lp_mix": 0.9999999999999929,
  "fc_floor": 4025.775082865489,
  "p": 0.7104244383847033
}
```

- Plots: `plots/polars/ShureSM57_polar.png`, `plots/colour/ShureSM57_colour.png`, `plots/fit/ShureSM57_{train,holdout}.png`
- Metrics JSON: `reports/ShureSM57_metrics.json`

### `SchoepsCMC5UCardioid` — Schoeps CMC5-U Cardioid — SDC

- Honesty: **MEASURED** · Family: `sdc_cardioid`
- Source: `Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles)`
- Train RMSE: **4.316 dB** (MSE 18.632)
- Hold-out RMSE: **5.326 dB** (MSE 28.370)
- Hold-out angles: [45.0, 135.0]
- Train angles: [0.0, 15.0, 30.0, 60.0, 90.0, 120.0, 150.0, 180.0]
- Fit log: `DE success=False nit=100 fun=18.524946; LS success=True cost=4770.048447`
- Params:

```json
{
  "f0": 800.0000000001402,
  "depth_max_db": -18.92327112534651,
  "res_hz": 1500.000000002899,
  "lp_mix": 0.9999999999991931,
  "fc_floor": 7999.999999753482,
  "p": 0.6867439764538247
}
```

- Plots: `plots/polars/SchoepsCMC5UCardioid_polar.png`, `plots/colour/SchoepsCMC5UCardioid_colour.png`, `plots/fit/SchoepsCMC5UCardioid_{train,holdout}.png`
- Metrics JSON: `reports/SchoepsCMC5UCardioid_metrics.json`

### `NeumannU87AiCardioid` — Neumann U87 Ai Cardioid — LDC

- Honesty: **MEASURED** · Family: `ldc_cardioid`
- Source: `Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles)`
- Train RMSE: **4.445 dB** (MSE 19.757)
- Hold-out RMSE: **4.515 dB** (MSE 20.385)
- Hold-out angles: [45.0, 135.0]
- Train angles: [0.0, 15.0, 30.0, 60.0, 90.0, 120.0, 150.0, 180.0]
- Fit log: `DE success=False nit=100 fun=19.643398; LS success=True cost=5058.004212`
- Params:

```json
{
  "f0": 800.0000000000001,
  "depth_max_db": -21.582007871580842,
  "res_hz": 1500.0000000000002,
  "lp_mix": 0.9999999999999999,
  "fc_floor": 4814.204208666394,
  "p": 0.7296195832760488
}
```

- Plots: `plots/polars/NeumannU87AiCardioid_polar.png`, `plots/colour/NeumannU87AiCardioid_colour.png`, `plots/fit/NeumannU87AiCardioid_{train,holdout}.png`
- Metrics JSON: `reports/NeumannU87AiCardioid_metrics.json`

### `RoyerR121` — Royer R-121 — fig-8 ribbon

- Honesty: **MEASURED** · Family: `fig8_ribbon`
- Source: `Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles)`
- Train RMSE: **9.235 dB** (MSE 85.282)
- Hold-out RMSE: **3.649 dB** (MSE 13.313)
- Hold-out angles: [45.0, 135.0]
- Train angles: [0.0, 15.0, 30.0, 60.0, 90.0, 120.0, 150.0, 180.0]
- Fit log: `DE success=False nit=100 fun=84.788418; LS success=True cost=21832.346200`
- Params:

```json
{
  "f0": 800.0000000000001,
  "depth_max_db": -18.275138497655444,
  "res_hz": 1500.0000000000146,
  "lp_mix": 0.9999999999999999,
  "fc_floor": 4721.839614815983,
  "p": 0.6000000000000001
}
```

- Plots: `plots/polars/RoyerR121_polar.png`, `plots/colour/RoyerR121_colour.png`, `plots/fit/RoyerR121_{train,holdout}.png`
- Metrics JSON: `reports/RoyerR121_metrics.json`

### `ElectroVoiceRE20` — Electro-Voice RE20 — dynamic cardioid

- Honesty: **MEASURED** · Family: `dynamic_cardioid`
- Source: `Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles)`
- Train RMSE: **4.745 dB** (MSE 22.512)
- Hold-out RMSE: **4.476 dB** (MSE 20.030)
- Hold-out angles: [45.0, 135.0]
- Train angles: [0.0, 15.0, 30.0, 60.0, 90.0, 120.0, 150.0, 180.0]
- Fit log: `DE success=False nit=100 fun=22.382379; LS success=True cost=5763.453443`
- Params:

```json
{
  "f0": 800.000000000007,
  "depth_max_db": -15.543523051544748,
  "res_hz": 15999.999999997484,
  "lp_mix": 0.9999999999999908,
  "fc_floor": 7721.419042761914,
  "p": 0.7256794199518184
}
```

- Plots: `plots/polars/ElectroVoiceRE20_polar.png`, `plots/colour/ElectroVoiceRE20_colour.png`, `plots/fit/ElectroVoiceRE20_{train,holdout}.png`
- Metrics JSON: `reports/ElectroVoiceRE20_metrics.json`

### `AKGC414Cardioid` — AKG C414 Cardioid — LDC multipattern

- Honesty: **MEASURED** · Family: `ldc_cardioid`
- Source: `Franco et al. Zenodo 10.5281/zenodo.4633508 (Raw_IRs, 5m, 24-bit, selected angles)`
- Train RMSE: **4.674 dB** (MSE 21.842)
- Hold-out RMSE: **4.989 dB** (MSE 24.893)
- Hold-out angles: [45.0, 135.0]
- Train angles: [0.0, 15.0, 30.0, 60.0, 90.0, 120.0, 150.0, 180.0]
- Fit log: `DE success=False nit=100 fun=21.716387; LS success=True cost=5591.937866`
- Params:

```json
{
  "f0": 800.0000000000002,
  "depth_max_db": -22.35855818890321,
  "res_hz": 1500.0000000000039,
  "lp_mix": 0.9999999999999687,
  "fc_floor": 5389.246575387094,
  "p": 0.7671282916891781
}
```

- Plots: `plots/polars/AKGC414Cardioid_polar.png`, `plots/colour/AKGC414Cardioid_colour.png`, `plots/fit/AKGC414Cardioid_{train,holdout}.png`
- Metrics JSON: `reports/AKGC414Cardioid_metrics.json`

## Evidence the fitter ran end-to-end

- Log file: [`logs/fit_run.log`](logs/fit_run.log)
- Per-mic metrics under `reports/*_metrics.json`
- Preset index: [`presets/index.json`](presets/index.json)
- This report timestamp: 2026-09-22 23:09 BST
- Wall time: 16.4 s for 6 mics

## How to re-run

```bat
cd "C:\Users\IdleHanz\Desktop\2011 Room Reverb\mic_fitter"
REM use software\.venv if present, else:
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python run_fit.py
```

With Zenodo WAVs extracted into `data\zenodo\`:

```bat
python run_fit.py
```

Force ASSUMED proxies:

```bat
python run_fit.py --no-zenodo
```

Box mirror:

```bash
cd /workspace/mic_fitter && source .venv/bin/activate && python run_fit.py
```



## Interpreting hold-out RMSE (~3.6–5.3 dB MEASURED)

Targets are **full relative magnitude** `H(θ)/H(0°)` (pattern level + colour).
The 6-scalar shelf+LP model cannot match deep rear-null geometry or sharp diffraction
notches — residual ~5 dB RMSE is **expected**, not a failed run. Colour curves and
polar galleries show where the smooth model tracks vs where measured lobing diverges.
ASSUMED proxies (pattern baked into synthetic targets similarly) sit under `presets/assumed/`
with much lower RMSE when the generator matches the model family.

## Limitations

- ASSUMED proxies ≠ measured Franco IRs until WAVs are provided.
- 6-scalar model will miss sharp diffraction notches / strong rear-lobe colour.
- Fig-8 side null is approximate.
- Polar plots combine geometric pattern + fitted colour (presentation aid).
- Absolute sensitivity / pad / proximity not modelled.

## Folder map on Desktop

```
C:/Users/IdleHanz/Desktop/2011 Room Reverb/mic_fitter/
  README.md
  MORNING_REPORT.md
  run_fit.py
  requirements.txt
  mic_fitter/          # package
  presets/             # *.json + index.json
  plots/
    polars/            # classic polar at 250/1k/4k/8k
    colour/            # off-axis colour curves
    fit/               # meas-vs-model train/holdout panels
  data/                # zenodo/ + manifest.json
  reports/             # metrics + gallery.html
  logs/fit_run.log
```

## Room software

Pointer only — **untouched**: `../software/` (Desktop) / `/workspace/2011-Room-Reverb/software/` (box).


---

## Desktop delivery status (2026-09-22 23:09 BST)

- **Box mirror complete:** `/workspace/mic_fitter/`
- **Packaged:** `/workspace/mic_fitter_desktop.tar.gz` (7.3 MB) — excludes `.venv` and the 1.4 GB Zenodo zip
- **Extracted Franco WAVs included** in the tarball under `data/zenodo/extracted/`
- **CopyFromBox to Desktop** requires parent/operator with machine tools — see `SYNC.md`
- Target path: `C:\Users\IdleHanz\Desktop\2011 Room Reverb\mic_fitter\`

### Quick open after sync

1. Open `MORNING_REPORT.md`
2. Open `reports/gallery.html` in a browser (mic gallery with polars + colour)
3. Browse `plots/polars/`, `plots/colour/`, `plots/fit/`
4. Load presets from `presets/*.json` (MEASURED) — ASSUMED demos in `presets/assumed/`
