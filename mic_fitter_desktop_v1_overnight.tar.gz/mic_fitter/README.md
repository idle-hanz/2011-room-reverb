# mic_fitter

**Standalone overnight tool** for Idle Hanz — fits a *tiny* off-axis microphone colour model  
so the 2011 Room Reverb app can load presets later.

> **Does not modify** the listened Room Reverb mix, AudioWorklet, or default engine path.  
> This folder is separate from `software/`.

## Honesty tags

| Tag | Meaning |
|-----|---------|
| **ASSUMED** | Synthetic / manufacturer-style proxy curves. Useful for plumbing + demos. **Not** lab truth. |
| **MEASURED** | Fitted from Franco et al. Zenodo IR WAVs when present under `data/zenodo/`. |
| **Structure LP** | Room-engine structure low-pass is **separate** — these presets are off-axis magnitude colour only. |

Zenodo dataset (preferred when available): https://zenodo.org/records/4633508  
(Franco, Brookes, De Sena — multi-angle mic IRs, ~1.5 GB zip.)

## Model (≤ 6 free scalars)

Relative response `H(θ) / H(0°)` in dB:

1. **High-shelf** — `f0`, `depth_max_db`
2. **Soft one-pole** — `res_hz`, `lp_mix`, `fc_floor`
3. **Angle law** — `½(1 − cos θ)^p` with free exponent `p`

Loss: dB MSE on log-spaced frequencies ~200 Hz–16 kHz; hold out some angles;  
smoothness penalty on extreme parameters.  
Optimiser: `scipy.optimize.differential_evolution` (+ `least_squares` polish). **No deep learning.**

## One-command run

```bat
cd "C:\Users\IdleHanz\Desktop\2011 Room Reverb\mic_fitter"
REM Prefer existing room venv if present:
REM   ..\software\.venv\Scripts\activate
REM else:
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python run_fit.py
```

On the agent box:

```bash
cd /workspace/mic_fitter
source .venv/bin/activate   # already created overnight
python run_fit.py
```

Outputs:

- `presets/*.json` — loadable later by the room app
- `presets/index.json` — catalog
- `plots/*_{train,holdout,overlay}.png` — meas/target vs model
- `MORNING_REPORT.md` — overnight summary + hold-out errors
- `data/manifest.json` — ASSUMED vs MEASURED note

Force synthetic even if WAVs exist: `python run_fit.py --no-zenodo`

## Pointing at Zenodo files

1. Download the zip from https://zenodo.org/records/4633508 (or extract only a few mics).
2. Place WAVs under `data/zenodo/` (any depth; names containing `30Deg` etc. are detected).
3. Re-run `python run_fit.py` — honesty flips to **MEASURED** for discovered mics.

## Room Reverb pointer

Room software lives at `../software/` (Desktop) / `/workspace/2011-Room-Reverb/software/` (box).  
**Untouched** by this tool. Future integration: read `mic_fitter/presets/*.json` as optional colour tables.

## Package layout

```
mic_fitter/
  README.md
  MORNING_REPORT.md
  requirements.txt
  run_fit.py
  mic_fitter/          # Python package
    model.py
    synthetic.py       # ASSUMED proxy curves
    data.py            # Zenodo loader + fallback
    fit.py
    plot.py
    export.py
  presets/
  plots/
  data/
```


## Overnight result snapshot (see MORNING_REPORT.md)

Fitted **6 MEASURED** mics from Franco et al. Zenodo `10.5281/zenodo.4633508`
(Raw_IRs, 5 m, 24-bit, angles 0…180°; hold-outs 45° & 135°):

| mic_id | type |
|--------|------|
| ShureSM57 | dynamic cardioid |
| SchoepsCMC5UCardioid | SDC cardioid |
| NeumannU87AiCardioid | LDC cardioid |
| RoyerR121 | fig-8 ribbon |
| ElectroVoiceRE20 | dynamic cardioid |
| AKGC414Cardioid | LDC cardioid |

Also retained **ASSUMED** proxy presets under `presets/assumed/` for plumbing demos.

Polar plots: `plots/polars/*_polar.png` (model) and `*_polar_measured.png`.  
Colour / fit panels: `plots/colour/`, `plots/fit/`.  
Gallery: `reports/gallery.html`.
