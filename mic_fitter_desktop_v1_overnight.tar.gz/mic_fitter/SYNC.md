# SYNC — copy mic_fitter to Desktop

**Dest:** `C:\Users\IdleHanz\Desktop\2011 Room Reverb\mic_fitter\`  
**machineId:** `9595fbf3-7e9f-488a-b70d-ab0e29294c12`  
**Box package:** `/workspace/mic_fitter_desktop.tar.gz` (7.3 MB, excludes 1.4 GB Zenodo zip + `.venv`)

## Parent agent / operator

1. `CopyFromBox` `/workspace/mic_fitter_desktop.tar.gz` →  
   `C:\Users\IdleHanz\Desktop\2011 Room Reverb\mic_fitter_desktop.tar.gz`
2. On Desktop machine Shell:

```powershell
cd "C:\Users\IdleHanz\Desktop\2011 Room Reverb"
if (Test-Path mic_fitter) { Rename-Item mic_fitter "mic_fitter_prev_$(Get-Date -Format yyyyMMdd_HHmm)" }
New-Item -ItemType Directory -Force -Path mic_fitter | Out-Null
tar -xzf mic_fitter_desktop.tar.gz
# tarball contains top-level mic_fitter/ — flatten if needed:
if (Test-Path .\mic_fitter\mic_fitter\run_fit.py) {
  # already nested correctly from tar -C workspace
}
# If extract created .\mic_fitter\mic_fitter\..., move up:
if (Test-Path .\mic_fitter\run_fit.py) { } else {
  Move-Item .\mic_fitter\mic_fitter\* .\mic_fitter\ -Force
}
```

Or recursive `CopyFromBox` of each file under `/workspace/mic_fitter/` (skip `.venv` and the big zip).

## Do not touch

`software\` mix / worklet / default engine — **untouched**.
