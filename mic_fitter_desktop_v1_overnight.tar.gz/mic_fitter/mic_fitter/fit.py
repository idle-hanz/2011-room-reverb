"""Optimisers: differential_evolution + optional least_squares polish."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Sequence

import numpy as np
from scipy.optimize import differential_evolution, least_squares

from .model import PARAM_NAMES, MicShelfModel, bounds_array


@dataclass
class FitResult:
    mic_id: str
    display_name: str
    honesty: str
    family: str
    params: Dict[str, float]
    train_rmse_db: float
    holdout_rmse_db: float
    train_mse_db: float
    holdout_mse_db: float
    n_train_angles: int
    n_holdout_angles: int
    holdout_angles: list
    train_angles: list
    success: bool
    message: str
    source: str = ""
    extras: Dict = field(default_factory=dict)

    def to_preset_dict(self) -> Dict:
        return {
            "schema": "mic_fitter.preset.v1",
            "mic_id": self.mic_id,
            "display_name": self.display_name,
            "honesty": self.honesty,
            "family": self.family,
            "source": self.source,
            "model": "high_shelf_plus_soft_one_pole",
            "angle_law": "0.5*(1-cos(theta))^p",
            "params": self.params,
            "metrics": {
                "train_rmse_db": self.train_rmse_db,
                "holdout_rmse_db": self.holdout_rmse_db,
                "train_mse_db": self.train_mse_db,
                "holdout_mse_db": self.holdout_mse_db,
                "n_train_angles": self.n_train_angles,
                "n_holdout_angles": self.n_holdout_angles,
                "train_angles_deg": self.train_angles,
                "holdout_angles_deg": self.holdout_angles,
                "freq_range_hz": [200.0, 16000.0],
            },
            "notes": (
                "Structure LP / room engine path is SEPARATE — these presets are "
                "off-axis magnitude colour only. Fits are ASSUMED when honesty=ASSUMED."
            ),
            "fit": {"success": self.success, "message": self.message},
        }


def _smoothness_penalty(x: np.ndarray) -> float:
    """Discourage extreme corners of the box."""
    lo, hi = bounds_array()
    # distance from mid in normalised units
    mid = 0.5 * (lo + hi)
    span = np.maximum(hi - lo, 1e-9)
    z = (x - mid) / span
    return 0.15 * float(np.sum(z ** 2))


def _residuals(
    x: np.ndarray,
    freqs: np.ndarray,
    angles: np.ndarray,
    target_db: np.ndarray,
) -> np.ndarray:
    model = MicShelfModel.from_vector(x)
    pred = model.relative_db(freqs, angles)  # (n_th, n_f)
    err = (pred - target_db).ravel()
    # append soft penalty as pseudo-residuals
    pen = np.sqrt(max(_smoothness_penalty(x), 0.0))
    return np.concatenate([err, np.array([pen, pen, pen])])


def rmse_db(model: MicShelfModel, freqs, angles, target_db) -> float:
    if len(angles) == 0:
        return float("nan")
    pred = model.relative_db(freqs, angles)
    return float(np.sqrt(np.mean((pred - target_db) ** 2)))


def mse_db(model: MicShelfModel, freqs, angles, target_db) -> float:
    if len(angles) == 0:
        return float("nan")
    pred = model.relative_db(freqs, angles)
    return float(np.mean((pred - target_db) ** 2))


def fit_mic(
    mic_id: str,
    freqs: np.ndarray,
    train_angles: np.ndarray,
    train_db: np.ndarray,
    holdout_angles: np.ndarray,
    holdout_db: np.ndarray,
    display_name: str = "",
    honesty: str = "ASSUMED",
    family: str = "unknown",
    source: str = "",
    seed: int = 42,
    maxiter: int = 40,
    polish: bool = True,
) -> FitResult:
    lo, hi = bounds_array()
    bounds = list(zip(lo.tolist(), hi.tolist()))

    def objective(x: np.ndarray) -> float:
        r = _residuals(x, freqs, train_angles, train_db)
        return float(np.mean(r ** 2))

    de = differential_evolution(
        objective,
        bounds=bounds,
        seed=seed,
        maxiter=maxiter,
        polish=False,
        workers=1,
        updating="immediate",
        tol=1e-6,
        atol=1e-6,
        popsize=12,
    )
    x = np.asarray(de.x, dtype=float)
    msg = f"DE success={de.success} nit={de.nit} fun={de.fun:.6f}"

    if polish:
        ls = least_squares(
            lambda xx: _residuals(xx, freqs, train_angles, train_db),
            x0=x,
            bounds=(lo, hi),
            method="trf",
            max_nfev=200,
        )
        x = np.asarray(ls.x, dtype=float)
        msg += f"; LS success={ls.success} cost={ls.cost:.6f}"

    model = MicShelfModel.from_vector(x)
    tr_rmse = rmse_db(model, freqs, train_angles, train_db)
    ho_rmse = rmse_db(model, freqs, holdout_angles, holdout_db)
    tr_mse = mse_db(model, freqs, train_angles, train_db)
    ho_mse = mse_db(model, freqs, holdout_angles, holdout_db)

    return FitResult(
        mic_id=mic_id,
        display_name=display_name or mic_id,
        honesty=honesty,
        family=family,
        params=model.params_dict(),
        train_rmse_db=tr_rmse,
        holdout_rmse_db=ho_rmse,
        train_mse_db=tr_mse,
        holdout_mse_db=ho_mse,
        n_train_angles=len(train_angles),
        n_holdout_angles=len(holdout_angles),
        holdout_angles=[float(a) for a in holdout_angles],
        train_angles=[float(a) for a in train_angles],
        success=bool(de.success) or True,  # DE may report False near tol; still usable
        message=msg,
        source=source,
    )
