"""Mic off-axis magnitude fitter — tiny high-shelf + soft one-pole model."""

__version__ = "0.1.0"

from .model import MicShelfModel, PARAM_NAMES, PARAM_BOUNDS
from .fit import fit_mic, FitResult

__all__ = [
    "MicShelfModel",
    "PARAM_NAMES",
    "PARAM_BOUNDS",
    "fit_mic",
    "FitResult",
    "__version__",
]
