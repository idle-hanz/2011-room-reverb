"""Tiny off-axis mic model: high-shelf + soft one-pole, angle law ½(1−cosθ)^p."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Mapping, Sequence, Tuple

import numpy as np

# Free scalars (max 6–8): shelf + soft LP + angle exponent
PARAM_NAMES: Tuple[str, ...] = (
    "f0",           # high-shelf corner Hz
    "depth_max_db", # max shelf depth (negative = cut) at 180°
    "res_hz",       # soft one-pole / resonance-ish knee Hz
    "lp_mix",       # 0..1 blend of soft LP into off-axis path
    "fc_floor",     # lowest effective LP cutoff Hz at extreme off-axis
    "p",            # angle-law exponent in ½(1−cosθ)^p
)

# (lo, hi) bounds for optimiser
PARAM_BOUNDS: Dict[str, Tuple[float, float]] = {
    "f0": (800.0, 12000.0),
    "depth_max_db": (-24.0, 0.0),
    "res_hz": (1500.0, 16000.0),
    "lp_mix": (0.0, 1.0),
    "fc_floor": (800.0, 8000.0),
    "p": (0.6, 3.5),
}


def angle_weight(theta_deg: np.ndarray | float, p: float) -> np.ndarray:
    """½(1 − cos θ)^p with θ in degrees. 0 at on-axis, →1 toward 180°."""
    th = np.asarray(theta_deg, dtype=float)
    # fold to [0, 180] for magnitude symmetry of typical cardioids
    th = np.abs(((th + 180.0) % 360.0) - 180.0)
    cos_t = np.cos(np.deg2rad(th))
    w = 0.5 * (1.0 - cos_t)
    w = np.clip(w, 0.0, 1.0) ** float(p)
    return w


def high_shelf_db(freqs: np.ndarray, f0: float, depth_db: float) -> np.ndarray:
    """Smooth high-shelf gain in dB (depth_db typically ≤ 0)."""
    f = np.asarray(freqs, dtype=float)
    # bilinear-ish log blend around f0
    x = np.log10(np.maximum(f, 1.0) / max(f0, 1.0))
    # sigmoid from ~0 below f0 to 1 above
    blend = 1.0 / (1.0 + np.exp(-4.0 * x))
    return depth_db * blend


def soft_one_pole_db(freqs: np.ndarray, fc) -> np.ndarray:
    """Soft one-pole low-pass magnitude in dB (approx |1 / (1 + j f/fc)|).

    `fc` may be scalar or broadcastable to `freqs` (e.g. (n_theta, 1)).
    """
    f = np.asarray(freqs, dtype=float)
    fc_arr = np.asarray(fc, dtype=float)
    fc_arr = np.maximum(fc_arr, 1.0)
    mag = 1.0 / np.sqrt(1.0 + (f / fc_arr) ** 2)
    return 20.0 * np.log10(np.maximum(mag, 1e-12))


@dataclass
class MicShelfModel:
    """Relative off-axis response H(θ)/H(0°) in dB vs frequency."""

    f0: float = 4000.0
    depth_max_db: float = -12.0
    res_hz: float = 6000.0
    lp_mix: float = 0.5
    fc_floor: float = 2500.0
    p: float = 1.2

    def params_dict(self) -> Dict[str, float]:
        return {k: float(getattr(self, k)) for k in PARAM_NAMES}

    @classmethod
    def from_vector(cls, x: Sequence[float]) -> "MicShelfModel":
        return cls(**{n: float(v) for n, v in zip(PARAM_NAMES, x)})

    def to_vector(self) -> np.ndarray:
        return np.array([getattr(self, n) for n in PARAM_NAMES], dtype=float)

    def relative_db(
        self,
        freqs: np.ndarray,
        theta_deg: float | np.ndarray,
    ) -> np.ndarray:
        """
        Model relative response in dB.

        Shape: if theta is scalar → (n_freq,); if array → (n_theta, n_freq).
        On-axis (θ=0) is identically 0 dB.
        """
        freqs = np.asarray(freqs, dtype=float)
        th = np.asarray(theta_deg, dtype=float)
        scalar = th.ndim == 0
        if scalar:
            th = th.reshape(1)

        w = angle_weight(th, self.p)  # (n_theta,)
        # effective shelf depth and LP cutoff scale with angle weight
        depth = self.depth_max_db * w[:, None]
        # fc interpolates from res_hz (on-axis, unused) down to fc_floor
        fc = self.res_hz + (self.fc_floor - self.res_hz) * w[:, None]
        # but only apply LP where weight > 0 via lp_mix
        shelf = high_shelf_db(freqs[None, :], self.f0, 1.0)  # unit depth curve
        shelf = shelf * depth

        lp = soft_one_pole_db(freqs[None, :], fc)
        # relative LP vs on-axis (on-axis soft LP at res_hz ≈ flatter): subtract on-axis LP
        lp0 = soft_one_pole_db(freqs, self.res_hz)
        lp_rel = (lp - lp0[None, :]) * self.lp_mix * w[:, None]

        out = shelf + lp_rel
        if scalar:
            return out[0]
        return out


def bounds_array() -> Tuple[np.ndarray, np.ndarray]:
    lo = np.array([PARAM_BOUNDS[n][0] for n in PARAM_NAMES], dtype=float)
    hi = np.array([PARAM_BOUNDS[n][1] for n in PARAM_NAMES], dtype=float)
    return lo, hi
